﻿Imports System.IO
Public Class Form1

    Dim EtatCivil As String = "D:\EtatCivil.txt"
    Dim Note As String = "D:\Note.txt"
    Dim Adresse As String = "D:\Adresse.txt"


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Label1.Visible = False
        Button1.Visible = False
        Button2.Visible = False

        Label3.Visible = True
        TextBox1.Visible = True
        Button4.Visible = True
        Label4.Visible = True
        ComboBox1.Visible = True
        Button5.Visible = True
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Label2.Visible = True
        TextBox1.Visible = True
        Button3.Visible = True
        Button4.Visible = True

        Label1.Visible = False
        Button1.Visible = False
        Button2.Visible = False



    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If (TextBox1.Text <> "") Then
            Dim MonTest As Boolean

            Dim monStreamReader As New StreamReader(EtatCivil)
            Dim ligne As String
            Do
                ligne = monStreamReader.ReadLine
                MonTest = ligne Like "*" & "" & TextBox1.Text & "" & "*"

                If (MonTest = True) Then
                    Exit Do
                End If
            Loop Until ligne Is Nothing
            monStreamReader.Close()

            If (MonTest = True) Then
                System.IO.File.WriteAllLines(EtatCivil, System.IO.File.ReadAllLines(EtatCivil).Where(New Func(Of String, Boolean)(Function(s As String) (Not s.Contains(TextBox1.Text)))))
                System.IO.File.WriteAllLines(Note, System.IO.File.ReadAllLines(Note).Where(New Func(Of String, Boolean)(Function(s As String) (Not s.Contains(TextBox1.Text)))))
                System.IO.File.WriteAllLines(Adresse, System.IO.File.ReadAllLines(Adresse).Where(New Func(Of String, Boolean)(Function(s As String) (Not s.Contains(TextBox1.Text)))))
                MsgBox("Le Numéro d'Etudiant et toutes ses attributs ont été supprimé !")
            Else
                MsgBox("Le Numéro n'existe pas !")
            End If

            
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Label2.Visible = False
        TextBox1.Visible = False
        Button3.Visible = False
        Button4.Visible = False
        Label4.Visible = False
        ComboBox1.Visible = False
        Label3.Visible = False
        Button5.Visible = False
        Button6.Visible = False
        RichTextBox1.Visible = False

        Label1.Visible = True
        Button1.Visible = True
        Button2.Visible = True
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        If (TextBox1.Text <> "" And ComboBox1.Text <> "" And (ComboBox1.Text = "EtatCivil.txt" Or ComboBox1.Text = "Note.txt" Or ComboBox1.Text = "Adresse.txt")) Then
            Dim MonTest As Boolean

            Dim monStreamReader As New StreamReader(EtatCivil)
            Dim ligne As String
            Do
                ligne = monStreamReader.ReadLine
                MonTest = ligne Like "*" & "" & TextBox1.Text & "" & "*"

                If (MonTest = True) Then
                    Exit Do
                End If
            Loop Until ligne Is Nothing
            monStreamReader.Close()

            If (MonTest = True) Then
                If (ComboBox1.Text <> "EtatCivil.txt") Then
                    monStreamReader = New StreamReader(Note)
                    Do
                        ligne = monStreamReader.ReadLine
                        MonTest = ligne Like "*" & "" & TextBox1.Text & "" & "*"

                        If (MonTest = True) Then
                            Exit Do
                        End If
                    Loop Until ligne Is Nothing
                    monStreamReader.Close()

                End If
                If (MonTest = True) Then

                    If (ComboBox1.Text = "Adresse.txt") Then
                        monStreamReader = New StreamReader(Adresse)
                        Do
                            ligne = monStreamReader.ReadLine
                            MonTest = ligne Like "*" & "" & TextBox1.Text & "" & "*"

                            If (MonTest = True) Then
                                Exit Do
                            End If
                        Loop Until ligne Is Nothing
                        monStreamReader.Close()
                    End If
                    Label3.Visible = False
                    TextBox1.Visible = False
                    Label4.Visible = False
                    ComboBox1.Visible = False
                    Button5.Visible = False
                    Button6.Visible = True
                    RichTextBox1.Visible = True
                    RichTextBox1.Text = ligne
                Else
                    MsgBox("Cette Etudiant ne possède pas de fichier Note.txt et Adresse.txt")
                End If

            Else
                MsgBox("Vous avez fait une erreur !")
            End If
        Else
            MsgBox("Il manque des informations ou vous avez fait une erreur !")
        End If

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        System.IO.File.WriteAllLines(EtatCivil, System.IO.File.ReadAllLines(EtatCivil).Where(New Func(Of String, Boolean)(Function(s As String) (Not s.Contains(TextBox1.Text)))))
        Dim test As System.IO.StreamWriter
        test = My.Computer.FileSystem.OpenTextFileWriter("D:\" + ComboBox1.Text, True)
        test.WriteLine(RichTextBox1.Text)
        test.Close()
        MsgBox("Modification Réussi")
    End Sub
End Class
