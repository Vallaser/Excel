﻿Imports System.IO
Public Class Form1

    Dim Repertoire As String = "D:\Etatcivil.txt"

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If (Numero.Text <> "" And Prenom.Text <> "" And Nom.Text <> "" And Nationalite.Text <> "" And IsNumeric(Numero.Text) = True And IsNumeric(Nom.Text) = False And IsNumeric(Prenom.Text) = False And IsNumeric(Nationalite.Text) = False) Then

            If Len(Dir(Repertoire)) > 0 Then

                Dim MonTest As Boolean

                Dim monStreamReader As New StreamReader(Repertoire)
                Dim ligne As String
                Do
                    ligne = monStreamReader.ReadLine
                    MonTest = ligne Like "*" & "" & Numero.Text & "" & "*"

                    If (MonTest = True) Then
                        MsgBox("Numero déjà utilisé")
                        Exit Do
                    End If

                Loop Until ligne Is Nothing
                monStreamReader.Close()

                If (MonTest <> True) Then
                    Dim file As System.IO.StreamWriter
                    file = My.Computer.FileSystem.OpenTextFileWriter(Repertoire, True)
                    file.WriteLine(Numero.Text + " " + Nom.Text + " " + Prenom.Text + " " + Nationalite.Text)
                    file.Close()
                End If

            Else
                Dim path As String = Repertoire
                Dim fs As FileStream = File.Create(path)
                fs.Close()

                Dim test As System.IO.StreamWriter
                test = My.Computer.FileSystem.OpenTextFileWriter(Repertoire, True)
                test.WriteLine(Numero.Text + " " + Nom.Text + " " + Prenom.Text + " " + Nationalite.Text)
                test.Close()

            End If

            Numero.Text = ""
            Prenom.Text = ""
            Nom.Text = ""
            Nationalite.Text = ""

            MsgBox("Création réussi !")

        Else
            MsgBox("Corrigez-vous !!!!")
        End If

    End Sub

    Sub lectureFichier(ByVal fichier As String)

        Try
            
        Catch ex As Exception
            MsgBox("Une erreur est survenue au cours de l'accès en lecture du fichier de configuration du logiciel." & vbCrLf & vbCrLf & "Veuillez vérifier l'emplacement : " & fichier, MsgBoxStyle.Critical, "Erreur lors e l'ouverture du fichier conf...")
        End Try
        'RichTextBox1.Text = texte
    End Sub



End Class
