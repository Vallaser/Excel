﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Numero = New System.Windows.Forms.TextBox()
        Me.Prenom = New System.Windows.Forms.TextBox()
        Me.Nationalite = New System.Windows.Forms.TextBox()
        Me.Nom = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Numero
        '
        Me.Numero.Location = New System.Drawing.Point(296, 152)
        Me.Numero.MaxLength = 20
        Me.Numero.Name = "Numero"
        Me.Numero.Size = New System.Drawing.Size(262, 20)
        Me.Numero.TabIndex = 0
        '
        'Prenom
        '
        Me.Prenom.Location = New System.Drawing.Point(296, 292)
        Me.Prenom.MaxLength = 10
        Me.Prenom.Name = "Prenom"
        Me.Prenom.Size = New System.Drawing.Size(262, 20)
        Me.Prenom.TabIndex = 1
        '
        'Nationalite
        '
        Me.Nationalite.Location = New System.Drawing.Point(296, 376)
        Me.Nationalite.MaxLength = 10
        Me.Nationalite.Name = "Nationalite"
        Me.Nationalite.Size = New System.Drawing.Size(262, 20)
        Me.Nationalite.TabIndex = 2
        '
        'Nom
        '
        Me.Nom.Location = New System.Drawing.Point(296, 223)
        Me.Nom.MaxLength = 20
        Me.Nom.Name = "Nom"
        Me.Nom.Size = New System.Drawing.Size(262, 20)
        Me.Nom.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(173, 155)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Numero Etudiant :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(188, 223)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Nom Etudiant :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(174, 295)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(91, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Prénom Etudiant :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(160, 379)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(105, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Nationalité Etudiant :"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(381, 498)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Enregistrer"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(901, 626)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Nom)
        Me.Controls.Add(Me.Nationalite)
        Me.Controls.Add(Me.Prenom)
        Me.Controls.Add(Me.Numero)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Numero As System.Windows.Forms.TextBox
    Friend WithEvents Prenom As System.Windows.Forms.TextBox
    Friend WithEvents Nationalite As System.Windows.Forms.TextBox
    Friend WithEvents Nom As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button

End Class
