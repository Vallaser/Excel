﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Numero = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Tp = New System.Windows.Forms.TextBox()
        Me.CodePostal = New System.Windows.Forms.TextBox()
        Me.DS = New System.Windows.Forms.TextBox()
        Me.Ville = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(311, 70)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(92, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Numero Etudiant :"
        '
        'Numero
        '
        Me.Numero.Location = New System.Drawing.Point(409, 67)
        Me.Numero.MaxLength = 10
        Me.Numero.Name = "Numero"
        Me.Numero.Size = New System.Drawing.Size(189, 20)
        Me.Numero.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(240, 170)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(163, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Note Tp Prammation sous excel :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(333, 352)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(70, 13)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Code Postal :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(238, 260)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(165, 13)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Note DS Prammation sous excel :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(371, 449)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(32, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Ville :"
        '
        'Tp
        '
        Me.Tp.Location = New System.Drawing.Point(409, 167)
        Me.Tp.MaxLength = 2
        Me.Tp.Name = "Tp"
        Me.Tp.Size = New System.Drawing.Size(189, 20)
        Me.Tp.TabIndex = 8
        '
        'CodePostal
        '
        Me.CodePostal.Location = New System.Drawing.Point(409, 349)
        Me.CodePostal.MaxLength = 5
        Me.CodePostal.Name = "CodePostal"
        Me.CodePostal.Size = New System.Drawing.Size(189, 20)
        Me.CodePostal.TabIndex = 9
        '
        'DS
        '
        Me.DS.Location = New System.Drawing.Point(409, 257)
        Me.DS.MaxLength = 5
        Me.DS.Name = "DS"
        Me.DS.Size = New System.Drawing.Size(189, 20)
        Me.DS.TabIndex = 10
        '
        'Ville
        '
        Me.Ville.Location = New System.Drawing.Point(409, 442)
        Me.Ville.MaxLength = 15
        Me.Ville.Name = "Ville"
        Me.Ville.Size = New System.Drawing.Size(189, 20)
        Me.Ville.TabIndex = 11
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(461, 507)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 12
        Me.Button1.Text = "Enregistrer"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1106, 552)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Ville)
        Me.Controls.Add(Me.DS)
        Me.Controls.Add(Me.CodePostal)
        Me.Controls.Add(Me.Tp)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Numero)
        Me.Controls.Add(Me.Label2)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Numero As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Tp As System.Windows.Forms.TextBox
    Friend WithEvents CodePostal As System.Windows.Forms.TextBox
    Friend WithEvents DS As System.Windows.Forms.TextBox
    Friend WithEvents Ville As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button

End Class
