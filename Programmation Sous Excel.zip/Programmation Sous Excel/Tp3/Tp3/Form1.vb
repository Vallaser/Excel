﻿Imports System.IO

Public Class Form1

    Dim EtatCivil As String = "D:\EtatCivil.txt"
    Dim Note As String = "D:\Note.txt"
    Dim Adresse As String = "D:\Adresse.txt"

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If (Numero.Text <> "" And Tp.Text <> "" And CodePostal.Text <> "" And DS.Text <> "" And Ville.Text <> "") Then

            Dim MonTest As Boolean

            Dim monStreamReader As New StreamReader(EtatCivil)
            Dim ligne As String
            Do
                ligne = monStreamReader.ReadLine
                MonTest = ligne Like "*" & "" & Numero.Text & "" & "*"

                If (MonTest = True) Then
                    Exit Do
                End If

            Loop Until ligne Is Nothing
            monStreamReader.Close()




            If (MonTest = False) Then
                MsgBox("Le Numero n'existe pas !")
                Numero.Text = ""
            Else
                MonTest = False
                If Len(Dir(Note)) > 0 Then

                    monStreamReader = New StreamReader(Note)
                    Do
                        ligne = monStreamReader.ReadLine
                        MonTest = ligne Like "*" & "" & Numero.Text & "" & "*"

                        If (MonTest = True) Then
                            MsgBox("Le Numero a déjà été utilisé !")
                            Numero.Text = ""
                            Exit Do
                        End If

                    Loop Until ligne Is Nothing
                    monStreamReader.Close()



                End If

                If (MonTest = False) Then
                    If Len(Dir(Note)) > 0 Then


                        Dim file As System.IO.StreamWriter
                        file = My.Computer.FileSystem.OpenTextFileWriter(Note, True)
                        file.WriteLine(Numero.Text + " " + Tp.Text + " " + DS.Text)
                        file.Close()
                    Else
                        Dim path As String = Note
                        Dim fs As FileStream = File.Create(path)
                        fs.Close()

                        Dim test As System.IO.StreamWriter
                        test = My.Computer.FileSystem.OpenTextFileWriter(Note, True)
                        test.WriteLine(Numero.Text + " " + Tp.Text + " " + DS.Text)
                        test.Close()
                    End If

                    If Len(Dir(Adresse)) > 0 Then
                        Dim file As System.IO.StreamWriter
                        file = My.Computer.FileSystem.OpenTextFileWriter(Adresse, True)
                        file.WriteLine(Numero.Text + " " + CodePostal.Text + " " + Ville.Text)
                        file.Close()
                    Else
                        Dim path As String = Adresse
                        Dim fs As FileStream = File.Create(path)
                        fs.Close()

                        Dim test As System.IO.StreamWriter
                        test = My.Computer.FileSystem.OpenTextFileWriter(Adresse, True)
                        test.WriteLine(Numero.Text + " " + CodePostal.Text + " " + Ville.Text)
                        test.Close()
                    End If
                    Tp.Text = ""
                    CodePostal.Text = ""
                    DS.Text = ""
                    Ville.Text = ""
                    Numero.Text = ""
                    MsgBox("Création Réussi !")
                End If

            End If

        Else
            MsgBox("Au moins un champ manquant !")
        End If

    End Sub
End Class
