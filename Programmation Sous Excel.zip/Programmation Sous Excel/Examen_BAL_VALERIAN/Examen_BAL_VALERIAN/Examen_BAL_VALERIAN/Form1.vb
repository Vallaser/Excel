﻿Imports System.IO
Imports System.Text

Public Class Form1

    'On va chercher les différents fichiers necessaires comme les images des feux ou les fichiers.txt
    Dim Rouge As String = "D:\Professionel\S6\Programmation Sous Excel\Examen_BAL_VALERIAN\Examen_BAL_VALERIAN\Examen_BAL_VALERIAN\Rouge.bmp"       'image rouge
    Dim Orange As String = "D:\Professionel\S6\Programmation Sous Excel\Examen_BAL_VALERIAN\Examen_BAL_VALERIAN\Examen_BAL_VALERIAN\Orange.bmp"     'image orange
    Dim Vert As String = "D:\Professionel\S6\Programmation Sous Excel\Examen_BAL_VALERIAN\Examen_BAL_VALERIAN\Examen_BAL_VALERIAN\Vert.bmp"         'image verte
    Dim Sortie As String = "D:\Professionel\S6\Programmation Sous Excel\Examen_BAL_VALERIAN\Examen_BAL_VALERIAN\Examen_BAL_VALERIAN\sortie.txt"     'sortie.txt
    Dim Entree As String = "D:\Professionel\S6\Programmation Sous Excel\Examen_BAL_VALERIAN\Examen_BAL_VALERIAN\Examen_BAL_VALERIAN\entree.txt"     'entree.txt

    'Toutes les varaibles necessaires communes à nosfonctions
    Dim words As String()   'tableau de chaines de caractères qui permet de lire le fichier entree.txt mot par mot
    Dim clignote As Boolean 'booléen qui vérifie si le feu orange est allumé ou pas
    Dim voix_A As String    'chaine de caractère qui nous dit quel est le feu à la voix A
    Dim voix_B As String    'chaine de caractère qui nous dit quel est le feu à la voix A
    Dim time As Integer     'entier qui s'incrémente à chaque raffraîchissement
    Dim time_A As Integer   'temps de la couleur du feu A en cours
    Dim time_B As Integer   'temps de la couleur du feu B en cours
    Dim secondes As Double  'double qui calcule le temps en secondes et le renvoie dans le fichier sortie.txt
    Dim Voiture_Bas(8) As System.Object             'tableau qui contient les 8 positions des voitures qui viennent du bas
    Dim Voiture_Haut(8) As System.Object            'tableau qui contient les 8 positions des voitures qui viennent du haut
    Dim Voiture_Droite(11) As System.Object         'tableau qui contient les 8 positions des voitures qui viennent de droite
    Dim Voiture_Gauche(11) As System.Object         'tableau qui contient les 8 positions des voitures qui viennent de gauche
    Dim Pieton_Haut_Haut(10) As System.Object       'tableau qui contient les 10 positions des pietons qui viennent du haut haut
    Dim Pieton_Haut_Bas(10) As System.Object        'tableau qui contient les 10 positions des pietons qui viennent du haut bas
    Dim Pieton_Bas_Haut(10) As System.Object        'tableau qui contient les 10 positions des pietons qui viennent du bas haut
    Dim Pieton_Bas_Bas(10) As System.Object         'tableau qui contient les 10 positions des pietons qui viennent du bas bas
    Dim Pieton_Droite_Droite(9) As System.Object    'tableau qui contient les 9 positions des pietons qui viennent de droite droite
    Dim Pieton_Droite_Gauche(9) As System.Object    'tableau qui contient les 9 positions des pietons qui viennent de droite gauche
    Dim Pieton_Gauche_Droite(9) As System.Object    'tableau qui contient les 9 positions des pietons qui viennent de gauche droite
    Dim Pieton_Gauche_Gauche(9) As System.Object    'tableau qui contient les 9 positions des pietons qui viennent de gauche gauche



    Private Sub Demarrer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Demarrer.Click
        If Len(Dir(Rouge)) > 0 And Len(Dir(Orange)) > 0 And Len(Dir(Vert)) > 0 Then

            'Toutes les positions possibles des voitures sont classés dans 4 tableaux, un tableau par voie

            Voiture_Bas(0) = Voiture_B_1
            Voiture_Bas(1) = Voiture_B_2
            Voiture_Bas(2) = Voiture_B_3
            Voiture_Bas(3) = Voiture_B_4
            Voiture_Bas(4) = Voiture_B_5
            Voiture_Bas(5) = Voiture_B_6
            Voiture_Bas(6) = Voiture_B_7
            Voiture_Bas(7) = Voiture_B_8

            Voiture_Haut(0) = Voiture_H_1
            Voiture_Haut(1) = Voiture_H_2
            Voiture_Haut(2) = Voiture_H_3
            Voiture_Haut(3) = Voiture_H_4
            Voiture_Haut(4) = Voiture_H_5
            Voiture_Haut(5) = Voiture_H_6
            Voiture_Haut(6) = Voiture_H_7
            Voiture_Haut(7) = Voiture_H_8

            Voiture_Droite(0) = Voiture_D_1
            Voiture_Droite(1) = Voiture_D_2
            Voiture_Droite(2) = Voiture_D_3
            Voiture_Droite(3) = Voiture_D_4
            Voiture_Droite(4) = Voiture_D_5
            Voiture_Droite(5) = Voiture_D_6
            Voiture_Droite(6) = Voiture_D_7
            Voiture_Droite(7) = Voiture_D_8
            Voiture_Droite(8) = Voiture_D_9
            Voiture_Droite(9) = Voiture_D_10
            Voiture_Droite(10) = Voiture_D_11

            Voiture_Gauche(0) = Voiture_G_1
            Voiture_Gauche(1) = Voiture_G_2
            Voiture_Gauche(2) = Voiture_G_3
            Voiture_Gauche(3) = Voiture_G_4
            Voiture_Gauche(4) = Voiture_G_5
            Voiture_Gauche(5) = Voiture_G_6
            Voiture_Gauche(6) = Voiture_G_7
            Voiture_Gauche(7) = Voiture_G_8
            Voiture_Gauche(8) = Voiture_G_9
            Voiture_Gauche(9) = Voiture_G_10
            Voiture_Gauche(10) = Voiture_G_11


            'Toutes les positions possibles des pietons sont classés dans 8 tableaux, un tableau par voie sens d'un passage pieton

            Pieton_Haut_Haut(0) = Pieton_H_H_1
            Pieton_Haut_Haut(1) = Pieton_H_H_2
            Pieton_Haut_Haut(2) = Pieton_H_H_3
            Pieton_Haut_Haut(3) = Pieton_H_H_4
            Pieton_Haut_Haut(4) = Pieton_H_H_5
            Pieton_Haut_Haut(5) = Pieton_H_H_6
            Pieton_Haut_Haut(6) = Pieton_H_H_7
            Pieton_Haut_Haut(7) = Pieton_H_H_8
            Pieton_Haut_Haut(8) = Pieton_H_H_9
            Pieton_Haut_Haut(9) = Pieton_H_H_10

            Pieton_Haut_Bas(0) = Pieton_H_B_1
            Pieton_Haut_Bas(1) = Pieton_H_B_2
            Pieton_Haut_Bas(2) = Pieton_H_B_3
            Pieton_Haut_Bas(3) = Pieton_H_B_4
            Pieton_Haut_Bas(4) = Pieton_H_B_5
            Pieton_Haut_Bas(5) = Pieton_H_B_6
            Pieton_Haut_Bas(6) = Pieton_H_B_7
            Pieton_Haut_Bas(7) = Pieton_H_B_8
            Pieton_Haut_Bas(8) = Pieton_H_B_9
            Pieton_Haut_Bas(9) = Pieton_H_B_10

            Pieton_Bas_Bas(0) = Pieton_B_B_1
            Pieton_Bas_Bas(1) = Pieton_B_B_2
            Pieton_Bas_Bas(2) = Pieton_B_B_3
            Pieton_Bas_Bas(3) = Pieton_B_B_4
            Pieton_Bas_Bas(4) = Pieton_B_B_5
            Pieton_Bas_Bas(5) = Pieton_B_B_6
            Pieton_Bas_Bas(6) = Pieton_B_B_7
            Pieton_Bas_Bas(7) = Pieton_B_B_8
            Pieton_Bas_Bas(8) = Pieton_B_B_9
            Pieton_Bas_Bas(9) = Pieton_B_B_10

            Pieton_Bas_Haut(0) = Pieton_B_H_1
            Pieton_Bas_Haut(1) = Pieton_B_H_2
            Pieton_Bas_Haut(2) = Pieton_B_H_3
            Pieton_Bas_Haut(3) = Pieton_B_H_4
            Pieton_Bas_Haut(4) = Pieton_B_H_5
            Pieton_Bas_Haut(5) = Pieton_B_H_6
            Pieton_Bas_Haut(6) = Pieton_B_H_7
            Pieton_Bas_Haut(7) = Pieton_B_H_8
            Pieton_Bas_Haut(8) = Pieton_B_H_9
            Pieton_Bas_Haut(9) = Pieton_B_H_10

            Pieton_Droite_Droite(0) = Pieton_D_D_1
            Pieton_Droite_Droite(1) = Pieton_D_D_2
            Pieton_Droite_Droite(2) = Pieton_D_D_3
            Pieton_Droite_Droite(3) = Pieton_D_D_4
            Pieton_Droite_Droite(4) = Pieton_D_D_5
            Pieton_Droite_Droite(5) = Pieton_D_D_6
            Pieton_Droite_Droite(6) = Pieton_D_D_7
            Pieton_Droite_Droite(7) = Pieton_D_D_8
            Pieton_Droite_Droite(8) = Pieton_D_D_9

            Pieton_Droite_Gauche(0) = Pieton_D_G_1
            Pieton_Droite_Gauche(1) = Pieton_D_G_2
            Pieton_Droite_Gauche(2) = Pieton_D_G_3
            Pieton_Droite_Gauche(3) = Pieton_D_G_4
            Pieton_Droite_Gauche(4) = Pieton_D_G_5
            Pieton_Droite_Gauche(5) = Pieton_D_G_6
            Pieton_Droite_Gauche(6) = Pieton_D_G_7
            Pieton_Droite_Gauche(7) = Pieton_D_G_8
            Pieton_Droite_Gauche(8) = Pieton_D_G_9

            Pieton_Gauche_Gauche(0) = Pieton_G_G_1
            Pieton_Gauche_Gauche(1) = Pieton_G_G_2
            Pieton_Gauche_Gauche(2) = Pieton_G_G_3
            Pieton_Gauche_Gauche(3) = Pieton_G_G_4
            Pieton_Gauche_Gauche(4) = Pieton_G_G_5
            Pieton_Gauche_Gauche(5) = Pieton_G_G_6
            Pieton_Gauche_Gauche(6) = Pieton_G_G_7
            Pieton_Gauche_Gauche(7) = Pieton_G_G_8
            Pieton_Gauche_Gauche(8) = Pieton_G_G_9

            Pieton_Gauche_Droite(0) = Pieton_G_D_1
            Pieton_Gauche_Droite(1) = Pieton_G_D_2
            Pieton_Gauche_Droite(2) = Pieton_G_D_3
            Pieton_Gauche_Droite(3) = Pieton_G_D_4
            Pieton_Gauche_Droite(4) = Pieton_G_D_5
            Pieton_Gauche_Droite(5) = Pieton_G_D_6
            Pieton_Gauche_Droite(6) = Pieton_G_D_7
            Pieton_Gauche_Droite(7) = Pieton_G_D_8
            Pieton_Gauche_Droite(8) = Pieton_G_D_9

            'Clear la fenêtre
            Arret_Click(sender, e)

            'Initialisation du timer qui nous donne l'intervalle de rafraîchissement
            Timer1.Interval = 100
            Timer1.Enabled = True
            Timer1.Start()
            time = 0
            secondes = 0

            'lit le fichier entree.txt et repartit les premieres valeurs dans un tableau et calcule une troisième et l'ajoute dans ce même tableau et les affiches
            Dim monStreamReader = New StreamReader(Entree)
            Dim ligne As String
            Do
                ligne = monStreamReader.ReadLine
                If (ligne Is Nothing) Then
                Else
                    words = ligne.ToString.Split(New Char() {" "c})
                End If
            Loop Until ligne Is Nothing
            monStreamReader.Close()
            Temps_Feu_Rouge.Text = "Temps du Feu Rouge : " + words(0)
            Temps_Feu_Vert.Text = "Temps du Feu Vert : " + words(1)
            words(2) = Val(words(0)) - Val(words(1))        'calcule le temps du feu Orange
            Temps_Feu_Orange.Text = "Temps du Feu Orange : " + words(2)


            'Initialise les feux
            voix_A = "Rouge"
            voix_B = "Vert"
            time_A = 0
            time_B = 0

            Pieton_Feu_Rouge_B_1_1.Image = System.Drawing.Bitmap.FromFile(Rouge)
            Pieton_Feu_Rouge_B_1_2.Image = System.Drawing.Bitmap.FromFile(Rouge)
            Pieton_Feu_Rouge_B_2_1.Image = System.Drawing.Bitmap.FromFile(Rouge)
            Pieton_Feu_Rouge_B_2_2.Image = System.Drawing.Bitmap.FromFile(Rouge)
            Feu_Rouge_Voie_A_1.Image = System.Drawing.Bitmap.FromFile(Rouge)
            Feu_Rouge_Voie_A_2.Image = System.Drawing.Bitmap.FromFile(Rouge)
            
            Pieton_Feu_Vert_A_1_1.Image = System.Drawing.Bitmap.FromFile(Vert)
            Pieton_Feu_Vert_A_1_2.Image = System.Drawing.Bitmap.FromFile(Vert)
            Pieton_Feu_Vert_A_2_1.Image = System.Drawing.Bitmap.FromFile(Vert)
            Pieton_Feu_Vert_A_2_2.Image = System.Drawing.Bitmap.FromFile(Vert)
            Feu_Vert_Voie_B_1.Image = System.Drawing.Bitmap.FromFile(Vert)
            Feu_Vert_Voie_B_2.Image = System.Drawing.Bitmap.FromFile(Vert)


            'Initialise les voitures sur la carte
            Dim i As Integer
            i = 0
            While (Val(Nombre_Voiture_B.Text) > i)
                Voiture_Bas(i).Visible = True
                i += 1
            End While
            i = 0
            While (Val(Nombre_Voiture_H.Text) > i)
                Voiture_Haut(i).Visible = True
                i += 1
            End While
            i = 0
            While (Val(Nombre_Voiture_D.Text) > i)
                Voiture_Droite(i).Visible = True
                i += 1
            End While
            i = 0
            While (Val(Nombre_Voiture_G.Text) > i)
                Voiture_Gauche(i).Visible = True
                i += 1
            End While


            'Initialise les piétons sur la carte
            If (Val(Nombre_Pietons_HB.Text) = 1) Then
                Pieton_Haut_Bas(0).Visible = True
            End If

            If (Val(Nombre_Pietons_GG.Text) = 1) Then
                Pieton_Gauche_Gauche(0).Visible = True
            End If

            If (Val(Nombre_Pietons_HH.Text) = 1) Then
                Pieton_Haut_Haut(0).Visible = True
            End If

            If (Val(Nombre_Pietons_BH.Text) = 1) Then
                Pieton_Bas_Haut(0).Visible = True
            End If

            If (Val(Nombre_Pietons_BB.Text) = 1) Then
                Pieton_Bas_Bas(0).Visible = True
            End If

            If (Val(Nombre_Pietons_GD.Text) = 1) Then
                Pieton_Gauche_Droite(0).Visible = True
            End If

            If (Val(Nombre_Pietons_DD.Text) = 1) Then
                Pieton_Droite_Droite(0).Visible = True
            End If

            If (Val(Nombre_Pietons_DG.Text) = 1) Then
                Pieton_Droite_Gauche(0).Visible = True
            End If

        Else
            MsgBox("Des fichiers sont manquants dans le répertoire source !") 'Nous informes si un des fichiers est absent ce qui empêche le lancement du programme
        End If

    End Sub

    Private Sub Arret_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Arret.Click


        'Stop le timer
        Timer1.Stop()


        'Affiche le temps écoulé et l'écrit
        Label_Temps.Text = "Temps : " + secondes.ToString
        My.Computer.FileSystem.DeleteFile(Sortie)
        Dim file As System.IO.StreamWriter
        file = My.Computer.FileSystem.OpenTextFileWriter(Sortie, True)
        file.Write(secondes)
        file.Close()

        'Réinitialise le temps en seconde et le raffraîchissemnt même si cela est inutile car on le refait au démmarage d'une nouvelle simulation c'est simplement par sécurité
        time = 0
        secondes = 0


        'Enlève toutes les images des feux
        Feu_Rouge_Voie_A_1.Image = Nothing
        Feu_Orange_Voie_A_1.Image = Nothing
        Feu_Vert_Voie_A_1.Image = Nothing

        Feu_Rouge_Voie_A_2.Image = Nothing
        Feu_Orange_Voie_A_2.Image = Nothing
        Feu_Vert_Voie_A_2.Image = Nothing

        Feu_Rouge_Voie_B_1.Image = Nothing
        Feu_Orange_Voie_B_1.Image = Nothing
        Feu_Vert_Voie_B_1.Image = Nothing

        Feu_Rouge_Voie_B_2.Image = Nothing
        Feu_Orange_Voie_B_2.Image = Nothing
        Feu_Vert_Voie_B_2.Image = Nothing

        Pieton_Feu_Vert_A_1_1.Image = Nothing
        Pieton_Feu_Vert_A_1_2.Image = Nothing
        Pieton_Feu_Vert_A_2_1.Image = Nothing
        Pieton_Feu_Vert_A_2_2.Image = Nothing

        Pieton_Feu_Rouge_B_1_1.Image = Nothing
        Pieton_Feu_Rouge_B_1_2.Image = Nothing
        Pieton_Feu_Rouge_B_2_1.Image = Nothing
        Pieton_Feu_Rouge_B_2_2.Image = Nothing

        Pieton_Feu_Rouge_A_1_1.Image = Nothing
        Pieton_Feu_Rouge_A_1_2.Image = Nothing
        Pieton_Feu_Rouge_A_2_1.Image = Nothing
        Pieton_Feu_Rouge_A_2_2.Image = Nothing

        Pieton_Feu_Vert_B_1_1.Image = Nothing
        Pieton_Feu_Vert_B_1_2.Image = Nothing
        Pieton_Feu_Vert_B_2_1.Image = Nothing
        Pieton_Feu_Vert_B_2_2.Image = Nothing


        'Enleve les pietons et les voitures sur la carte
        Dim i As Integer
        i = 0
        While (8 > i)
            Voiture_Haut(i).Visible = False
            Voiture_Bas(i).Visible = False
            i += 1
        End While
        i = 0
        While (11 > i)
            Voiture_Gauche(i).Visible = False
            Voiture_Droite(i).Visible = False
            i += 1
        End While
        i = 0
        While (10 > i)
            Pieton_Haut_Haut(i).Visible = False
            Pieton_Haut_Bas(i).Visible = False
            Pieton_Bas_Haut(i).Visible = False
            Pieton_Bas_Bas(i).Visible = False
            i += 1
        End While
        i = 0
        While (9 > i)
            Pieton_Droite_Droite(i).Visible = False
            Pieton_Droite_Gauche(i).Visible = False
            Pieton_Gauche_Gauche(i).Visible = False
            Pieton_Gauche_Droite(i).Visible = False
            i += 1
        End While
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick

        time += 1


        If (time >= 5) Then 'correspond à 0,5 secondes
            time_A += 1
            time_B += 1
            secondes += 0.5

            'Fais les déplacments des voitures qui ont dépacés le passage piéton 
            Dim i As Integer
            i = 10
            While (i > 2)
                If (Voiture_Gauche(i).Visible = True) Then
                    If (i < 10) Then
                        Voiture_Gauche(i + 1).Visible = True
                    End If
                    Voiture_Gauche(i).Visible = False
                End If
                If (Voiture_Droite(i).Visible = True) Then
                    If (i < 10) Then
                        Voiture_Droite(i + 1).Visible = True
                    End If
                    Voiture_Droite(i).Visible = False
                End If
                i -= 1
            End While
            i = 7
            While (i > 2)
                If (Voiture_Haut(i).Visible = True) Then
                    If (i < 7) Then
                        Voiture_Haut(i + 1).Visible = True
                    End If
                    Voiture_Haut(i).Visible = False
                End If
                i -= 1
            End While
            i = 7
            While (i > 1)
                If (Voiture_Bas(i).Visible = True) Then
                    If (i < 7) Then
                        Voiture_Bas(i + 1).Visible = True
                    End If
                    Voiture_Bas(i).Visible = False
                End If
                i -= 1
            End While


            'Fais le déplacement des pietons qui se sont engagés sur un passage piéton de la voix A
            i = 9
            While (i > 0)
                If (Pieton_Bas_Bas(i).Visible = True) Then
                    If (i < 9) Then
                        Pieton_Bas_Bas(i + 1).Visible = True
                    End If
                    Pieton_Bas_Bas(i).Visible = False
                End If
                If (Pieton_Bas_Haut(i).Visible = True) Then
                    If (i < 9) Then
                        Pieton_Bas_Haut(i + 1).Visible = True
                    End If
                    Pieton_Bas_Haut(i).Visible = False
                End If
                If (Pieton_Haut_Haut(i).Visible = True) Then
                    If (i < 9) Then
                        Pieton_Haut_Haut(i + 1).Visible = True
                    End If
                    Pieton_Haut_Haut(i).Visible = False
                End If
                If (Pieton_Haut_Bas(i).Visible = True) Then
                    If (i < 9) Then
                        Pieton_Haut_Bas(i + 1).Visible = True
                    End If
                    Pieton_Haut_Bas(i).Visible = False
                End If
                i -= 1
            End While

            'Fais le déplacement des pietons qui se sont engagés sur un passage piéton de la voix B
            i = 8
            While (i > 0)
                If (Pieton_Droite_Droite(i).Visible = True) Then
                    If (i < 8) Then
                        Pieton_Droite_Droite(i + 1).Visible = True
                    End If
                    Pieton_Droite_Droite(i).Visible = False
                End If
                If (Pieton_Droite_Gauche(i).Visible = True) Then
                    If (i < 8) Then
                        Pieton_Droite_Gauche(i + 1).Visible = True
                    End If
                    Pieton_Droite_Gauche(i).Visible = False
                End If
                If (Pieton_Gauche_Gauche(i).Visible = True) Then
                    If (i < 8) Then
                        Pieton_Gauche_Gauche(i + 1).Visible = True
                    End If
                    Pieton_Gauche_Gauche(i).Visible = False
                End If
                If (Pieton_Gauche_Droite(i).Visible = True) Then
                    If (i < 8) Then
                        Pieton_Gauche_Droite(i + 1).Visible = True
                    End If
                    Pieton_Gauche_Droite(i).Visible = False
                End If
                i -= 1
            End While





            If (voix_A = "Vert") Then   'Fais l'engagement des voitures de la voix A et des pietons de la voie B
                i = 1
                While (i > -1)
                    If (Voiture_Bas(i).Visible = True) Then
                        Voiture_Bas(i + 1).Visible = True
                        Voiture_Bas(i).Visible = False
                    End If
                    i -= 1
                End While
                i = 2
                While (i > -1)
                    If (Voiture_Haut(i).Visible = True) Then
                        Voiture_Haut(i + 1).Visible = True
                        Voiture_Haut(i).Visible = False
                    End If
                    i -= 1
                End While

                If (Pieton_Gauche_Gauche(0).Visible = True) Then
                    Pieton_Gauche_Gauche(1).Visible = True
                    Pieton_Gauche_Gauche(0).Visible = False
                End If

                If (Pieton_Gauche_Droite(0).Visible = True) Then
                    Pieton_Gauche_Droite(1).Visible = True
                    Pieton_Gauche_Droite(0).Visible = False
                End If

                If (Pieton_Droite_Droite(0).Visible = True) Then
                    Pieton_Droite_Droite(1).Visible = True
                    Pieton_Droite_Droite(0).Visible = False
                End If

                If (Pieton_Droite_Gauche(0).Visible = True) Then
                    Pieton_Droite_Gauche(1).Visible = True
                    Pieton_Droite_Gauche(0).Visible = False
                End If

            ElseIf (voix_B = "Vert") Then   'Fais l'engagement des voitures de la voie B et des pietons de la voie A
                i = 2
                While (i > -1)
                    If (Voiture_Droite(i).Visible = True) Then
                        Voiture_Droite(i + 1).Visible = True
                        Voiture_Droite(i).Visible = False
                    End If
                    If (Voiture_Gauche(i).Visible = True) Then
                        Voiture_Gauche(i + 1).Visible = True
                        Voiture_Gauche(i).Visible = False
                    End If
                    i -= 1
                End While

                If (Pieton_Haut_Haut(0).Visible = True) Then
                    Pieton_Haut_Haut(1).Visible = True
                    Pieton_Haut_Haut(0).Visible = False
                End If

                If (Pieton_Haut_Bas(0).Visible = True) Then
                    Pieton_Haut_Bas(1).Visible = True
                    Pieton_Haut_Bas(0).Visible = False
                End If

                If (Pieton_Bas_Bas(0).Visible = True) Then
                    Pieton_Bas_Bas(1).Visible = True
                    Pieton_Bas_Bas(0).Visible = False
                End If

                If (Pieton_Bas_Haut(0).Visible = True) Then
                    Pieton_Bas_Haut(1).Visible = True
                    Pieton_Bas_Haut(0).Visible = False
                End If
            End If


            If (voix_A = "Rouge" And time_A >= words(0)) Then   'Si le feu de la voie A est rouge est qu'il a atteint son temps limite
                Feu_Rouge_Voie_A_1.Image = Nothing
                Feu_Rouge_Voie_A_2.Image = Nothing
                Feu_Orange_Voie_B_1.Image = Nothing
                Feu_Orange_Voie_B_2.Image = Nothing
                Feu_Vert_Voie_B_1.Image = Nothing
                Feu_Vert_Voie_B_2.Image = Nothing
                Feu_Vert_Voie_A_1.Image = System.Drawing.Bitmap.FromFile(Vert)
                Feu_Vert_Voie_A_2.Image = System.Drawing.Bitmap.FromFile(Vert)
                Feu_Rouge_Voie_B_1.Image = System.Drawing.Bitmap.FromFile(Rouge)
                Feu_Rouge_Voie_B_2.Image = System.Drawing.Bitmap.FromFile(Rouge)
                voix_A = "Vert"
                voix_B = "Rouge"
                time_A = 0
                time_B = 0
                Pieton_Feu_Rouge_B_1_1.Image = Nothing
                Pieton_Feu_Rouge_B_1_2.Image = Nothing
                Pieton_Feu_Rouge_B_2_1.Image = Nothing
                Pieton_Feu_Rouge_B_2_2.Image = Nothing
                Pieton_Feu_Vert_A_1_1.Image = Nothing
                Pieton_Feu_Vert_A_1_2.Image = Nothing
                Pieton_Feu_Vert_A_2_1.Image = Nothing
                Pieton_Feu_Vert_A_2_2.Image = Nothing
                Pieton_Feu_Vert_B_1_1.Image = System.Drawing.Bitmap.FromFile(Vert)
                Pieton_Feu_Vert_B_1_2.Image = System.Drawing.Bitmap.FromFile(Vert)
                Pieton_Feu_Vert_B_2_1.Image = System.Drawing.Bitmap.FromFile(Vert)
                Pieton_Feu_Vert_B_2_2.Image = System.Drawing.Bitmap.FromFile(Vert)
                Pieton_Feu_Rouge_A_1_1.Image = System.Drawing.Bitmap.FromFile(Rouge)
                Pieton_Feu_Rouge_A_1_2.Image = System.Drawing.Bitmap.FromFile(Rouge)
                Pieton_Feu_Rouge_A_2_1.Image = System.Drawing.Bitmap.FromFile(Rouge)
                Pieton_Feu_Rouge_A_2_2.Image = System.Drawing.Bitmap.FromFile(Rouge)


            ElseIf (voix_B = "Rouge" And time_B >= words(0)) Then    'Si le feu de la voie B est rouge est qu'il a atteint son temps limite
                Feu_Rouge_Voie_B_1.Image = Nothing
                Feu_Rouge_Voie_B_2.Image = Nothing
                Feu_Orange_Voie_A_1.Image = Nothing
                Feu_Orange_Voie_A_2.Image = Nothing
                Feu_Vert_Voie_A_1.Image = Nothing
                Feu_Vert_Voie_A_2.Image = Nothing
                Feu_Vert_Voie_B_1.Image = System.Drawing.Bitmap.FromFile(Vert)
                Feu_Vert_Voie_B_2.Image = System.Drawing.Bitmap.FromFile(Vert)
                Feu_Rouge_Voie_A_1.Image = System.Drawing.Bitmap.FromFile(Rouge)
                Feu_Rouge_Voie_A_2.Image = System.Drawing.Bitmap.FromFile(Rouge)
                voix_B = "Vert"
                voix_A = "Rouge"
                time_B = 0
                time_A = 0
                Pieton_Feu_Rouge_A_1_1.Image = Nothing
                Pieton_Feu_Rouge_A_1_2.Image = Nothing
                Pieton_Feu_Rouge_A_2_1.Image = Nothing
                Pieton_Feu_Rouge_A_2_2.Image = Nothing
                Pieton_Feu_Vert_B_1_1.Image = Nothing
                Pieton_Feu_Vert_B_1_2.Image = Nothing
                Pieton_Feu_Vert_B_2_1.Image = Nothing
                Pieton_Feu_Vert_B_2_2.Image = Nothing
                Pieton_Feu_Vert_A_1_1.Image = System.Drawing.Bitmap.FromFile(Vert)
                Pieton_Feu_Vert_A_1_2.Image = System.Drawing.Bitmap.FromFile(Vert)
                Pieton_Feu_Vert_A_2_1.Image = System.Drawing.Bitmap.FromFile(Vert)
                Pieton_Feu_Vert_A_2_2.Image = System.Drawing.Bitmap.FromFile(Vert)
                Pieton_Feu_Rouge_B_1_1.Image = System.Drawing.Bitmap.FromFile(Rouge)
                Pieton_Feu_Rouge_B_1_2.Image = System.Drawing.Bitmap.FromFile(Rouge)
                Pieton_Feu_Rouge_B_2_1.Image = System.Drawing.Bitmap.FromFile(Rouge)
                Pieton_Feu_Rouge_B_2_2.Image = System.Drawing.Bitmap.FromFile(Rouge)


            ElseIf (voix_A = "Vert" And time_A >= words(1)) Then     'Si le feu de la voie A est vert est qu'il a atteint son temps limite
                Feu_Vert_Voie_A_1.Image = Nothing
                Feu_Vert_Voie_A_2.Image = Nothing
                Feu_Rouge_Voie_A_1.Image = Nothing
                Feu_Rouge_Voie_A_2.Image = Nothing
                Feu_Orange_Voie_A_1.Image = System.Drawing.Bitmap.FromFile(Orange)
                Feu_Orange_Voie_A_2.Image = System.Drawing.Bitmap.FromFile(Orange)
                voix_A = "Orange"
                clignote = 0
                time_A = 0
                Pieton_Feu_Vert_B_1_1.Image = Nothing
                Pieton_Feu_Vert_B_1_2.Image = Nothing
                Pieton_Feu_Vert_B_2_1.Image = Nothing
                Pieton_Feu_Vert_B_2_2.Image = Nothing
                Pieton_Feu_Rouge_B_1_1.Image = System.Drawing.Bitmap.FromFile(Rouge)
                Pieton_Feu_Rouge_B_1_2.Image = System.Drawing.Bitmap.FromFile(Rouge)
                Pieton_Feu_Rouge_B_2_1.Image = System.Drawing.Bitmap.FromFile(Rouge)
                Pieton_Feu_Rouge_B_2_2.Image = System.Drawing.Bitmap.FromFile(Rouge)

            ElseIf (voix_B = "Vert" And time_B >= words(1)) Then     'Si le feu de la voie B est vert est qu'il a atteint son temps limite
                Feu_Vert_Voie_B_1.Image = Nothing
                Feu_Vert_Voie_B_2.Image = Nothing
                Feu_Rouge_Voie_B_1.Image = Nothing
                Feu_Rouge_Voie_B_2.Image = Nothing
                Feu_Orange_Voie_B_1.Image = System.Drawing.Bitmap.FromFile(Orange)
                Feu_Orange_Voie_B_2.Image = System.Drawing.Bitmap.FromFile(Orange)
                voix_B = "Orange"
                clignote = 0
                time_B = 0
                Pieton_Feu_Vert_A_1_1.Image = Nothing
                Pieton_Feu_Vert_A_1_2.Image = Nothing
                Pieton_Feu_Vert_A_2_1.Image = Nothing
                Pieton_Feu_Vert_A_2_2.Image = Nothing
                Pieton_Feu_Rouge_A_1_1.Image = System.Drawing.Bitmap.FromFile(Rouge)
                Pieton_Feu_Rouge_A_1_2.Image = System.Drawing.Bitmap.FromFile(Rouge)
                Pieton_Feu_Rouge_A_2_1.Image = System.Drawing.Bitmap.FromFile(Rouge)
                Pieton_Feu_Rouge_A_2_2.Image = System.Drawing.Bitmap.FromFile(Rouge)

            ElseIf (voix_A = "Orange") Then  'Si le feu de la voie A est orange on va le faire clignoter
                If (clignote = 0) Then
                    Feu_Orange_Voie_A_1.Image = Nothing
                    Feu_Orange_Voie_A_2.Image = Nothing
                    clignote = 1
                Else
                    Feu_Orange_Voie_A_1.Image = System.Drawing.Bitmap.FromFile(Orange)
                    Feu_Orange_Voie_A_2.Image = System.Drawing.Bitmap.FromFile(Orange)
                    clignote = 0
                End If

            ElseIf (voix_B = "Orange") Then 'Si le feu de la voie B est orange on va le faire clignoter
                If (clignote = 0) Then
                    Feu_Orange_Voie_B_1.Image = Nothing
                    Feu_Orange_Voie_B_2.Image = Nothing
                    clignote = 1
                Else
                    Feu_Orange_Voie_B_1.Image = System.Drawing.Bitmap.FromFile(Orange)
                    Feu_Orange_Voie_B_2.Image = System.Drawing.Bitmap.FromFile(Orange)
                    clignote = 0
                End If
            End If
            time = 0
        End If

    End Sub

End Class
