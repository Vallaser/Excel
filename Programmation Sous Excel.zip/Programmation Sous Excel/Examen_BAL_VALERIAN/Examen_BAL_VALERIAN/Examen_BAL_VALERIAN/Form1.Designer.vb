﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Demarrer = New System.Windows.Forms.Button()
        Me.Arret = New System.Windows.Forms.Button()
        Me.Feu_Rouge_Voie_B_1 = New System.Windows.Forms.PictureBox()
        Me.Feu_Rouge_Voie_A_2 = New System.Windows.Forms.PictureBox()
        Me.Feu_Rouge_Voie_B_2 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label_Temps = New System.Windows.Forms.Label()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.Pieton_B_B_9 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_B_H_2 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_B_H_3 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_B_B_8 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_B_B_7 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_B_H_4 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_B_H_5 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_B_B_6 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_B_B_5 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_B_H_6 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_B_H_7 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_B_B_4 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_B_B_3 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_B_H_8 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_B_H_9 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_B_B_2 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_H_9 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_B_2 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_H_8 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_B_3 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_H_7 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_B_4 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_H_6 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_B_5 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_H_5 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_B_6 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_H_4 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_B_7 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_H_3 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_B_8 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_H_2 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_B_9 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_D_D_2 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_D_G_8 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_D_G_7 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_D_D_3 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_D_D_4 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_D_G_6 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_D_G_5 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_D_D_5 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_D_D_6 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_D_G_4 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_D_G_3 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_D_D_7 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_D_D_8 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_D_G_2 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_G_D_2 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_G_D_3 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_G_D_4 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_G_D_5 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_G_D_6 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_G_D_7 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_G_D_8 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_G_G_8 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_G_G_7 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_G_G_6 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_G_G_5 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_G_G_4 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_G_G_3 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_G_G_2 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_B_B_1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_G_D_1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_B_H_10 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_G_G_9 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_B_1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_G_G_1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_H_10 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_G_D_9 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_D_G_1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_B_10 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_D_D_9 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_H_H_1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_B_B_10 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_B_H_1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_D_D_1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Pieton_D_G_9 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape11 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape12 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape10 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape9 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape8 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape7 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape6 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape5 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_H_6 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_H_7 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_B_8 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_B_7 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_B_6 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_B_5 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_B_4 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_B_3 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_H_8 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_B_2 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_H_5 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_H_4 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_H_3 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_H_2 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_D_9 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_D_11 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_D_10 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_D_8 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_D_7 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_D_6 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_G_6 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_D_5 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_G_9 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_G_10 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_G_11 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_G_8 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_D_4 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_D_3 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_D_2 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_G_7 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_G_5 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_G_4 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_G_3 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_G_2 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_H_1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_B_1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_D_1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Voiture_G_1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape4 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape3 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape2 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.LineShape8 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.LineShape7 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.LineShape6 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.LineShape5 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.LineShape4 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.LineShape3 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.LineShape2 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.LineShape1 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.Temps_Feu_Rouge = New System.Windows.Forms.Label()
        Me.Temps_Feu_Vert = New System.Windows.Forms.Label()
        Me.Temps_Feu_Orange = New System.Windows.Forms.Label()
        Me.Feu_Rouge_Voie_A_1 = New System.Windows.Forms.PictureBox()
        Me.Feu_Vert_Voie_A_1 = New System.Windows.Forms.PictureBox()
        Me.Feu_Orange_Voie_A_1 = New System.Windows.Forms.PictureBox()
        Me.Feu_Orange_Voie_B_1 = New System.Windows.Forms.PictureBox()
        Me.Feu_Vert_Voie_B_1 = New System.Windows.Forms.PictureBox()
        Me.Feu_Orange_Voie_A_2 = New System.Windows.Forms.PictureBox()
        Me.Feu_Vert_Voie_A_2 = New System.Windows.Forms.PictureBox()
        Me.Feu_Vert_Voie_B_2 = New System.Windows.Forms.PictureBox()
        Me.Feu_Orange_Voie_B_2 = New System.Windows.Forms.PictureBox()
        Me.Pieton_Feu_Vert_B_1_1 = New System.Windows.Forms.PictureBox()
        Me.Pieton_Feu_Rouge_B_1_1 = New System.Windows.Forms.PictureBox()
        Me.Pieton_Feu_Rouge_B_1_2 = New System.Windows.Forms.PictureBox()
        Me.Pieton_Feu_Vert_B_1_2 = New System.Windows.Forms.PictureBox()
        Me.Pieton_Feu_Vert_B_2_2 = New System.Windows.Forms.PictureBox()
        Me.Pieton_Feu_Rouge_B_2_2 = New System.Windows.Forms.PictureBox()
        Me.Pieton_Feu_Vert_B_2_1 = New System.Windows.Forms.PictureBox()
        Me.Pieton_Feu_Rouge_B_2_1 = New System.Windows.Forms.PictureBox()
        Me.Pieton_Feu_Rouge_A_2_2 = New System.Windows.Forms.PictureBox()
        Me.Pieton_Feu_Vert_A_2_2 = New System.Windows.Forms.PictureBox()
        Me.Pieton_Feu_Vert_A_2_1 = New System.Windows.Forms.PictureBox()
        Me.Pieton_Feu_Rouge_A_2_1 = New System.Windows.Forms.PictureBox()
        Me.Pieton_Feu_Rouge_A_1_2 = New System.Windows.Forms.PictureBox()
        Me.Pieton_Feu_Vert_A_1_2 = New System.Windows.Forms.PictureBox()
        Me.Pieton_Feu_Rouge_A_1_1 = New System.Windows.Forms.PictureBox()
        Me.Pieton_Feu_Vert_A_1_1 = New System.Windows.Forms.PictureBox()
        Me.Nombre_Voiture_B = New System.Windows.Forms.ComboBox()
        Me.Nombre_Voiture_G = New System.Windows.Forms.ComboBox()
        Me.Nombre_Voiture_D = New System.Windows.Forms.ComboBox()
        Me.Nombre_Voiture_H = New System.Windows.Forms.ComboBox()
        Me.Nombre_Pietons_GG = New System.Windows.Forms.ComboBox()
        Me.Nombre_Pietons_HB = New System.Windows.Forms.ComboBox()
        Me.Nombre_Pietons_BB = New System.Windows.Forms.ComboBox()
        Me.Nombre_Pietons_BH = New System.Windows.Forms.ComboBox()
        Me.Nombre_Pietons_HH = New System.Windows.Forms.ComboBox()
        Me.Nombre_Pietons_DG = New System.Windows.Forms.ComboBox()
        Me.Nombre_Pietons_DD = New System.Windows.Forms.ComboBox()
        Me.Nombre_Pietons_GD = New System.Windows.Forms.ComboBox()
        CType(Me.Feu_Rouge_Voie_B_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Feu_Rouge_Voie_A_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Feu_Rouge_Voie_B_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Feu_Rouge_Voie_A_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Feu_Vert_Voie_A_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Feu_Orange_Voie_A_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Feu_Orange_Voie_B_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Feu_Vert_Voie_B_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Feu_Orange_Voie_A_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Feu_Vert_Voie_A_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Feu_Vert_Voie_B_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Feu_Orange_Voie_B_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pieton_Feu_Vert_B_1_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pieton_Feu_Rouge_B_1_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pieton_Feu_Rouge_B_1_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pieton_Feu_Vert_B_1_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pieton_Feu_Vert_B_2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pieton_Feu_Rouge_B_2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pieton_Feu_Vert_B_2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pieton_Feu_Rouge_B_2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pieton_Feu_Rouge_A_2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pieton_Feu_Vert_A_2_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pieton_Feu_Vert_A_2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pieton_Feu_Rouge_A_2_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pieton_Feu_Rouge_A_1_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pieton_Feu_Vert_A_1_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pieton_Feu_Rouge_A_1_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pieton_Feu_Vert_A_1_1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Demarrer
        '
        Me.Demarrer.Location = New System.Drawing.Point(85, 27)
        Me.Demarrer.Name = "Demarrer"
        Me.Demarrer.Size = New System.Drawing.Size(75, 23)
        Me.Demarrer.TabIndex = 0
        Me.Demarrer.Text = "Demarrer"
        Me.Demarrer.UseVisualStyleBackColor = True
        '
        'Arret
        '
        Me.Arret.Location = New System.Drawing.Point(204, 27)
        Me.Arret.Name = "Arret"
        Me.Arret.Size = New System.Drawing.Size(75, 23)
        Me.Arret.TabIndex = 1
        Me.Arret.Text = "Arrêt"
        Me.Arret.UseVisualStyleBackColor = True
        '
        'Feu_Rouge_Voie_B_1
        '
        Me.Feu_Rouge_Voie_B_1.ErrorImage = Nothing
        Me.Feu_Rouge_Voie_B_1.InitialImage = Nothing
        Me.Feu_Rouge_Voie_B_1.Location = New System.Drawing.Point(1007, 247)
        Me.Feu_Rouge_Voie_B_1.Name = "Feu_Rouge_Voie_B_1"
        Me.Feu_Rouge_Voie_B_1.Size = New System.Drawing.Size(47, 52)
        Me.Feu_Rouge_Voie_B_1.TabIndex = 7
        Me.Feu_Rouge_Voie_B_1.TabStop = False
        '
        'Feu_Rouge_Voie_A_2
        '
        Me.Feu_Rouge_Voie_A_2.ErrorImage = Nothing
        Me.Feu_Rouge_Voie_A_2.InitialImage = Nothing
        Me.Feu_Rouge_Voie_A_2.Location = New System.Drawing.Point(895, 551)
        Me.Feu_Rouge_Voie_A_2.Name = "Feu_Rouge_Voie_A_2"
        Me.Feu_Rouge_Voie_A_2.Size = New System.Drawing.Size(43, 29)
        Me.Feu_Rouge_Voie_A_2.TabIndex = 8
        Me.Feu_Rouge_Voie_A_2.TabStop = False
        '
        'Feu_Rouge_Voie_B_2
        '
        Me.Feu_Rouge_Voie_B_2.ErrorImage = Nothing
        Me.Feu_Rouge_Voie_B_2.InitialImage = Nothing
        Me.Feu_Rouge_Voie_B_2.Location = New System.Drawing.Point(446, 465)
        Me.Feu_Rouge_Voie_B_2.Name = "Feu_Rouge_Voie_B_2"
        Me.Feu_Rouge_Voie_B_2.Size = New System.Drawing.Size(41, 49)
        Me.Feu_Rouge_Voie_B_2.TabIndex = 11
        Me.Feu_Rouge_Voie_B_2.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(253, 366)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Voie B"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(1259, 366)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Voie B"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(761, 642)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 13)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "Voie A"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(761, 12)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(38, 13)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "Voie A"
        '
        'Timer1
        '
        '
        'Label_Temps
        '
        Me.Label_Temps.AutoSize = True
        Me.Label_Temps.Location = New System.Drawing.Point(335, 37)
        Me.Label_Temps.Name = "Label_Temps"
        Me.Label_Temps.Size = New System.Drawing.Size(45, 13)
        Me.Label_Temps.TabIndex = 18
        Me.Label_Temps.Text = "Temps :"
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.Pieton_B_B_9, Me.Pieton_B_H_2, Me.Pieton_B_H_3, Me.Pieton_B_B_8, Me.Pieton_B_B_7, Me.Pieton_B_H_4, Me.Pieton_B_H_5, Me.Pieton_B_B_6, Me.Pieton_B_B_5, Me.Pieton_B_H_6, Me.Pieton_B_H_7, Me.Pieton_B_B_4, Me.Pieton_B_B_3, Me.Pieton_B_H_8, Me.Pieton_B_H_9, Me.Pieton_B_B_2, Me.Pieton_H_H_9, Me.Pieton_H_B_2, Me.Pieton_H_H_8, Me.Pieton_H_B_3, Me.Pieton_H_H_7, Me.Pieton_H_B_4, Me.Pieton_H_H_6, Me.Pieton_H_B_5, Me.Pieton_H_H_5, Me.Pieton_H_B_6, Me.Pieton_H_H_4, Me.Pieton_H_B_7, Me.Pieton_H_H_3, Me.Pieton_H_B_8, Me.Pieton_H_H_2, Me.Pieton_H_B_9, Me.Pieton_D_D_2, Me.Pieton_D_G_8, Me.Pieton_D_G_7, Me.Pieton_D_D_3, Me.Pieton_D_D_4, Me.Pieton_D_G_6, Me.Pieton_D_G_5, Me.Pieton_D_D_5, Me.Pieton_D_D_6, Me.Pieton_D_G_4, Me.Pieton_D_G_3, Me.Pieton_D_D_7, Me.Pieton_D_D_8, Me.Pieton_D_G_2, Me.Pieton_G_D_2, Me.Pieton_G_D_3, Me.Pieton_G_D_4, Me.Pieton_G_D_5, Me.Pieton_G_D_6, Me.Pieton_G_D_7, Me.Pieton_G_D_8, Me.Pieton_G_G_8, Me.Pieton_G_G_7, Me.Pieton_G_G_6, Me.Pieton_G_G_5, Me.Pieton_G_G_4, Me.Pieton_G_G_3, Me.Pieton_G_G_2, Me.Pieton_B_B_1, Me.Pieton_G_D_1, Me.Pieton_B_H_10, Me.Pieton_G_G_9, Me.Pieton_H_B_1, Me.Pieton_G_G_1, Me.Pieton_H_H_10, Me.Pieton_G_D_9, Me.Pieton_D_G_1, Me.Pieton_H_B_10, Me.Pieton_D_D_9, Me.Pieton_H_H_1, Me.Pieton_B_B_10, Me.Pieton_B_H_1, Me.Pieton_D_D_1, Me.Pieton_D_G_9, Me.RectangleShape11, Me.RectangleShape12, Me.RectangleShape10, Me.RectangleShape9, Me.RectangleShape8, Me.RectangleShape7, Me.RectangleShape6, Me.RectangleShape5, Me.Voiture_H_6, Me.Voiture_H_7, Me.Voiture_B_8, Me.Voiture_B_7, Me.Voiture_B_6, Me.Voiture_B_5, Me.Voiture_B_4, Me.Voiture_B_3, Me.Voiture_H_8, Me.Voiture_B_2, Me.Voiture_H_5, Me.Voiture_H_4, Me.Voiture_H_3, Me.Voiture_H_2, Me.Voiture_D_9, Me.Voiture_D_11, Me.Voiture_D_10, Me.Voiture_D_8, Me.Voiture_D_7, Me.Voiture_D_6, Me.Voiture_G_6, Me.Voiture_D_5, Me.Voiture_G_9, Me.Voiture_G_10, Me.Voiture_G_11, Me.Voiture_G_8, Me.Voiture_D_4, Me.Voiture_D_3, Me.Voiture_D_2, Me.Voiture_G_7, Me.Voiture_G_5, Me.Voiture_G_4, Me.Voiture_G_3, Me.Voiture_G_2, Me.Voiture_H_1, Me.Voiture_B_1, Me.Voiture_D_1, Me.Voiture_G_1, Me.RectangleShape4, Me.RectangleShape3, Me.RectangleShape2, Me.RectangleShape1, Me.LineShape8, Me.LineShape7, Me.LineShape6, Me.LineShape5, Me.LineShape4, Me.LineShape3, Me.LineShape2, Me.LineShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(1636, 711)
        Me.ShapeContainer1.TabIndex = 19
        Me.ShapeContainer1.TabStop = False
        '
        'Pieton_B_B_9
        '
        Me.Pieton_B_B_9.Location = New System.Drawing.Point(855, 498)
        Me.Pieton_B_B_9.Name = "Pieton_B_B_9"
        Me.Pieton_B_B_9.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_B_B_9.Visible = False
        '
        'Pieton_B_H_2
        '
        Me.Pieton_B_H_2.Location = New System.Drawing.Point(854, 481)
        Me.Pieton_B_H_2.Name = "Pieton_B_H_2"
        Me.Pieton_B_H_2.Size = New System.Drawing.Size(8, 9)
        Me.Pieton_B_H_2.Visible = False
        '
        'Pieton_B_H_3
        '
        Me.Pieton_B_H_3.Location = New System.Drawing.Point(831, 481)
        Me.Pieton_B_H_3.Name = "Pieton_B_H_3"
        Me.Pieton_B_H_3.Size = New System.Drawing.Size(8, 9)
        Me.Pieton_B_H_3.Visible = False
        '
        'Pieton_B_B_8
        '
        Me.Pieton_B_B_8.Location = New System.Drawing.Point(832, 498)
        Me.Pieton_B_B_8.Name = "Pieton_B_B_8"
        Me.Pieton_B_B_8.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_B_B_8.Visible = False
        '
        'Pieton_B_B_7
        '
        Me.Pieton_B_B_7.Location = New System.Drawing.Point(806, 497)
        Me.Pieton_B_B_7.Name = "Pieton_B_B_7"
        Me.Pieton_B_B_7.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_B_B_7.Visible = False
        '
        'Pieton_B_H_4
        '
        Me.Pieton_B_H_4.Location = New System.Drawing.Point(805, 480)
        Me.Pieton_B_H_4.Name = "Pieton_B_H_4"
        Me.Pieton_B_H_4.Size = New System.Drawing.Size(8, 9)
        Me.Pieton_B_H_4.Visible = False
        '
        'Pieton_B_H_5
        '
        Me.Pieton_B_H_5.Location = New System.Drawing.Point(783, 480)
        Me.Pieton_B_H_5.Name = "Pieton_B_H_5"
        Me.Pieton_B_H_5.Size = New System.Drawing.Size(8, 9)
        Me.Pieton_B_H_5.Visible = False
        '
        'Pieton_B_B_6
        '
        Me.Pieton_B_B_6.Location = New System.Drawing.Point(784, 497)
        Me.Pieton_B_B_6.Name = "Pieton_B_B_6"
        Me.Pieton_B_B_6.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_B_B_6.Visible = False
        '
        'Pieton_B_B_5
        '
        Me.Pieton_B_B_5.Location = New System.Drawing.Point(766, 496)
        Me.Pieton_B_B_5.Name = "Pieton_B_B_5"
        Me.Pieton_B_B_5.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_B_B_5.Visible = False
        '
        'Pieton_B_H_6
        '
        Me.Pieton_B_H_6.Location = New System.Drawing.Point(765, 479)
        Me.Pieton_B_H_6.Name = "Pieton_B_H_6"
        Me.Pieton_B_H_6.Size = New System.Drawing.Size(8, 9)
        Me.Pieton_B_H_6.Visible = False
        '
        'Pieton_B_H_7
        '
        Me.Pieton_B_H_7.Location = New System.Drawing.Point(746, 479)
        Me.Pieton_B_H_7.Name = "Pieton_B_H_7"
        Me.Pieton_B_H_7.Size = New System.Drawing.Size(8, 9)
        Me.Pieton_B_H_7.Visible = False
        '
        'Pieton_B_B_4
        '
        Me.Pieton_B_B_4.Location = New System.Drawing.Point(747, 496)
        Me.Pieton_B_B_4.Name = "Pieton_B_B_4"
        Me.Pieton_B_B_4.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_B_B_4.Visible = False
        '
        'Pieton_B_B_3
        '
        Me.Pieton_B_B_3.Location = New System.Drawing.Point(725, 497)
        Me.Pieton_B_B_3.Name = "Pieton_B_B_3"
        Me.Pieton_B_B_3.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_B_B_3.Visible = False
        '
        'Pieton_B_H_8
        '
        Me.Pieton_B_H_8.Location = New System.Drawing.Point(724, 480)
        Me.Pieton_B_H_8.Name = "Pieton_B_H_8"
        Me.Pieton_B_H_8.Size = New System.Drawing.Size(8, 9)
        Me.Pieton_B_H_8.Visible = False
        '
        'Pieton_B_H_9
        '
        Me.Pieton_B_H_9.Location = New System.Drawing.Point(702, 480)
        Me.Pieton_B_H_9.Name = "Pieton_B_H_9"
        Me.Pieton_B_H_9.Size = New System.Drawing.Size(8, 9)
        Me.Pieton_B_H_9.Visible = False
        '
        'Pieton_B_B_2
        '
        Me.Pieton_B_B_2.Location = New System.Drawing.Point(703, 497)
        Me.Pieton_B_B_2.Name = "Pieton_B_B_2"
        Me.Pieton_B_B_2.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_B_B_2.Visible = False
        '
        'Pieton_H_H_9
        '
        Me.Pieton_H_H_9.Location = New System.Drawing.Point(707, 252)
        Me.Pieton_H_H_9.Name = "Pieton_H_H_9"
        Me.Pieton_H_H_9.Size = New System.Drawing.Size(8, 9)
        Me.Pieton_H_H_9.Visible = False
        '
        'Pieton_H_B_2
        '
        Me.Pieton_H_B_2.Location = New System.Drawing.Point(708, 269)
        Me.Pieton_H_B_2.Name = "Pieton_H_B_2"
        Me.Pieton_H_B_2.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_H_B_2.Visible = False
        '
        'Pieton_H_H_8
        '
        Me.Pieton_H_H_8.Location = New System.Drawing.Point(729, 252)
        Me.Pieton_H_H_8.Name = "Pieton_H_H_8"
        Me.Pieton_H_H_8.Size = New System.Drawing.Size(8, 9)
        Me.Pieton_H_H_8.Visible = False
        '
        'Pieton_H_B_3
        '
        Me.Pieton_H_B_3.Location = New System.Drawing.Point(730, 269)
        Me.Pieton_H_B_3.Name = "Pieton_H_B_3"
        Me.Pieton_H_B_3.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_H_B_3.Visible = False
        '
        'Pieton_H_H_7
        '
        Me.Pieton_H_H_7.Location = New System.Drawing.Point(751, 251)
        Me.Pieton_H_H_7.Name = "Pieton_H_H_7"
        Me.Pieton_H_H_7.Size = New System.Drawing.Size(8, 9)
        Me.Pieton_H_H_7.Visible = False
        '
        'Pieton_H_B_4
        '
        Me.Pieton_H_B_4.Location = New System.Drawing.Point(752, 268)
        Me.Pieton_H_B_4.Name = "Pieton_H_B_4"
        Me.Pieton_H_B_4.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_H_B_4.Visible = False
        '
        'Pieton_H_H_6
        '
        Me.Pieton_H_H_6.Location = New System.Drawing.Point(770, 251)
        Me.Pieton_H_H_6.Name = "Pieton_H_H_6"
        Me.Pieton_H_H_6.Size = New System.Drawing.Size(8, 9)
        Me.Pieton_H_H_6.Visible = False
        '
        'Pieton_H_B_5
        '
        Me.Pieton_H_B_5.Location = New System.Drawing.Point(771, 268)
        Me.Pieton_H_B_5.Name = "Pieton_H_B_5"
        Me.Pieton_H_B_5.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_H_B_5.Visible = False
        '
        'Pieton_H_H_5
        '
        Me.Pieton_H_H_5.Location = New System.Drawing.Point(788, 252)
        Me.Pieton_H_H_5.Name = "Pieton_H_H_5"
        Me.Pieton_H_H_5.Size = New System.Drawing.Size(8, 9)
        Me.Pieton_H_H_5.Visible = False
        '
        'Pieton_H_B_6
        '
        Me.Pieton_H_B_6.Location = New System.Drawing.Point(789, 269)
        Me.Pieton_H_B_6.Name = "Pieton_H_B_6"
        Me.Pieton_H_B_6.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_H_B_6.Visible = False
        '
        'Pieton_H_H_4
        '
        Me.Pieton_H_H_4.Location = New System.Drawing.Point(810, 252)
        Me.Pieton_H_H_4.Name = "Pieton_H_H_4"
        Me.Pieton_H_H_4.Size = New System.Drawing.Size(8, 9)
        Me.Pieton_H_H_4.Visible = False
        '
        'Pieton_H_B_7
        '
        Me.Pieton_H_B_7.Location = New System.Drawing.Point(811, 269)
        Me.Pieton_H_B_7.Name = "Pieton_H_B_7"
        Me.Pieton_H_B_7.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_H_B_7.Visible = False
        '
        'Pieton_H_H_3
        '
        Me.Pieton_H_H_3.Location = New System.Drawing.Point(836, 253)
        Me.Pieton_H_H_3.Name = "Pieton_H_H_3"
        Me.Pieton_H_H_3.Size = New System.Drawing.Size(8, 9)
        Me.Pieton_H_H_3.Visible = False
        '
        'Pieton_H_B_8
        '
        Me.Pieton_H_B_8.Location = New System.Drawing.Point(837, 270)
        Me.Pieton_H_B_8.Name = "Pieton_H_B_8"
        Me.Pieton_H_B_8.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_H_B_8.Visible = False
        '
        'Pieton_H_H_2
        '
        Me.Pieton_H_H_2.Location = New System.Drawing.Point(859, 253)
        Me.Pieton_H_H_2.Name = "Pieton_H_H_2"
        Me.Pieton_H_H_2.Size = New System.Drawing.Size(8, 9)
        Me.Pieton_H_H_2.Visible = False
        '
        'Pieton_H_B_9
        '
        Me.Pieton_H_B_9.Location = New System.Drawing.Point(860, 270)
        Me.Pieton_H_B_9.Name = "Pieton_H_B_9"
        Me.Pieton_H_B_9.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_H_B_9.Visible = False
        '
        'Pieton_D_D_2
        '
        Me.Pieton_D_D_2.Location = New System.Drawing.Point(928, 429)
        Me.Pieton_D_D_2.Name = "Pieton_D_D_2"
        Me.Pieton_D_D_2.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_D_D_2.Visible = False
        '
        'Pieton_D_G_8
        '
        Me.Pieton_D_G_8.Location = New System.Drawing.Point(907, 430)
        Me.Pieton_D_G_8.Name = "Pieton_D_G_8"
        Me.Pieton_D_G_8.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_D_G_8.Visible = False
        '
        'Pieton_D_G_7
        '
        Me.Pieton_D_G_7.Location = New System.Drawing.Point(908, 410)
        Me.Pieton_D_G_7.Name = "Pieton_D_G_7"
        Me.Pieton_D_G_7.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_D_G_7.Visible = False
        '
        'Pieton_D_D_3
        '
        Me.Pieton_D_D_3.Location = New System.Drawing.Point(929, 408)
        Me.Pieton_D_D_3.Name = "Pieton_D_D_3"
        Me.Pieton_D_D_3.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_D_D_3.Visible = False
        '
        'Pieton_D_D_4
        '
        Me.Pieton_D_D_4.Location = New System.Drawing.Point(928, 391)
        Me.Pieton_D_D_4.Name = "Pieton_D_D_4"
        Me.Pieton_D_D_4.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_D_D_4.Visible = False
        '
        'Pieton_D_G_6
        '
        Me.Pieton_D_G_6.Location = New System.Drawing.Point(908, 392)
        Me.Pieton_D_G_6.Name = "Pieton_D_G_6"
        Me.Pieton_D_G_6.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_D_G_6.Visible = False
        '
        'Pieton_D_G_5
        '
        Me.Pieton_D_G_5.Location = New System.Drawing.Point(908, 374)
        Me.Pieton_D_G_5.Name = "Pieton_D_G_5"
        Me.Pieton_D_G_5.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_D_G_5.Visible = False
        '
        'Pieton_D_D_5
        '
        Me.Pieton_D_D_5.Location = New System.Drawing.Point(929, 373)
        Me.Pieton_D_D_5.Name = "Pieton_D_D_5"
        Me.Pieton_D_D_5.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_D_D_5.Visible = False
        '
        'Pieton_D_D_6
        '
        Me.Pieton_D_D_6.Location = New System.Drawing.Point(929, 353)
        Me.Pieton_D_D_6.Name = "Pieton_D_D_6"
        Me.Pieton_D_D_6.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_D_D_6.Visible = False
        '
        'Pieton_D_G_4
        '
        Me.Pieton_D_G_4.Location = New System.Drawing.Point(908, 354)
        Me.Pieton_D_G_4.Name = "Pieton_D_G_4"
        Me.Pieton_D_G_4.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_D_G_4.Visible = False
        '
        'Pieton_D_G_3
        '
        Me.Pieton_D_G_3.Location = New System.Drawing.Point(909, 335)
        Me.Pieton_D_G_3.Name = "Pieton_D_G_3"
        Me.Pieton_D_G_3.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_D_G_3.Visible = False
        '
        'Pieton_D_D_7
        '
        Me.Pieton_D_D_7.Location = New System.Drawing.Point(929, 334)
        Me.Pieton_D_D_7.Name = "Pieton_D_D_7"
        Me.Pieton_D_D_7.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_D_D_7.Visible = False
        '
        'Pieton_D_D_8
        '
        Me.Pieton_D_D_8.Location = New System.Drawing.Point(929, 312)
        Me.Pieton_D_D_8.Name = "Pieton_D_D_8"
        Me.Pieton_D_D_8.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_D_D_8.Visible = False
        '
        'Pieton_D_G_2
        '
        Me.Pieton_D_G_2.Location = New System.Drawing.Point(909, 313)
        Me.Pieton_D_G_2.Name = "Pieton_D_G_2"
        Me.Pieton_D_G_2.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_D_G_2.Visible = False
        '
        'Pieton_G_D_2
        '
        Me.Pieton_G_D_2.Location = New System.Drawing.Point(647, 431)
        Me.Pieton_G_D_2.Name = "Pieton_G_D_2"
        Me.Pieton_G_D_2.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_G_D_2.Visible = False
        '
        'Pieton_G_D_3
        '
        Me.Pieton_G_D_3.Location = New System.Drawing.Point(648, 410)
        Me.Pieton_G_D_3.Name = "Pieton_G_D_3"
        Me.Pieton_G_D_3.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_G_D_3.Visible = False
        '
        'Pieton_G_D_4
        '
        Me.Pieton_G_D_4.Location = New System.Drawing.Point(647, 393)
        Me.Pieton_G_D_4.Name = "Pieton_G_D_4"
        Me.Pieton_G_D_4.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_G_D_4.Visible = False
        '
        'Pieton_G_D_5
        '
        Me.Pieton_G_D_5.Location = New System.Drawing.Point(648, 375)
        Me.Pieton_G_D_5.Name = "Pieton_G_D_5"
        Me.Pieton_G_D_5.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_G_D_5.Visible = False
        '
        'Pieton_G_D_6
        '
        Me.Pieton_G_D_6.Location = New System.Drawing.Point(648, 355)
        Me.Pieton_G_D_6.Name = "Pieton_G_D_6"
        Me.Pieton_G_D_6.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_G_D_6.Visible = False
        '
        'Pieton_G_D_7
        '
        Me.Pieton_G_D_7.Location = New System.Drawing.Point(648, 336)
        Me.Pieton_G_D_7.Name = "Pieton_G_D_7"
        Me.Pieton_G_D_7.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_G_D_7.Visible = False
        '
        'Pieton_G_D_8
        '
        Me.Pieton_G_D_8.Location = New System.Drawing.Point(648, 314)
        Me.Pieton_G_D_8.Name = "Pieton_G_D_8"
        Me.Pieton_G_D_8.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_G_D_8.Visible = False
        '
        'Pieton_G_G_8
        '
        Me.Pieton_G_G_8.Location = New System.Drawing.Point(626, 432)
        Me.Pieton_G_G_8.Name = "Pieton_G_G_8"
        Me.Pieton_G_G_8.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_G_G_8.Visible = False
        '
        'Pieton_G_G_7
        '
        Me.Pieton_G_G_7.Location = New System.Drawing.Point(627, 412)
        Me.Pieton_G_G_7.Name = "Pieton_G_G_7"
        Me.Pieton_G_G_7.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_G_G_7.Visible = False
        '
        'Pieton_G_G_6
        '
        Me.Pieton_G_G_6.Location = New System.Drawing.Point(627, 394)
        Me.Pieton_G_G_6.Name = "Pieton_G_G_6"
        Me.Pieton_G_G_6.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_G_G_6.Visible = False
        '
        'Pieton_G_G_5
        '
        Me.Pieton_G_G_5.Location = New System.Drawing.Point(627, 376)
        Me.Pieton_G_G_5.Name = "Pieton_G_G_5"
        Me.Pieton_G_G_5.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_G_G_5.Visible = False
        '
        'Pieton_G_G_4
        '
        Me.Pieton_G_G_4.Location = New System.Drawing.Point(627, 356)
        Me.Pieton_G_G_4.Name = "Pieton_G_G_4"
        Me.Pieton_G_G_4.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_G_G_4.Visible = False
        '
        'Pieton_G_G_3
        '
        Me.Pieton_G_G_3.Location = New System.Drawing.Point(628, 337)
        Me.Pieton_G_G_3.Name = "Pieton_G_G_3"
        Me.Pieton_G_G_3.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_G_G_3.Visible = False
        '
        'Pieton_G_G_2
        '
        Me.Pieton_G_G_2.Location = New System.Drawing.Point(628, 315)
        Me.Pieton_G_G_2.Name = "Pieton_G_G_2"
        Me.Pieton_G_G_2.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_G_G_2.Visible = False
        '
        'Pieton_B_B_1
        '
        Me.Pieton_B_B_1.Location = New System.Drawing.Point(649, 496)
        Me.Pieton_B_B_1.Name = "Pieton_B_B_1"
        Me.Pieton_B_B_1.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_B_B_1.Visible = False
        '
        'Pieton_G_D_1
        '
        Me.Pieton_G_D_1.Location = New System.Drawing.Point(640, 477)
        Me.Pieton_G_D_1.Name = "Pieton_G_D_1"
        Me.Pieton_G_D_1.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_G_D_1.Visible = False
        '
        'Pieton_B_H_10
        '
        Me.Pieton_B_H_10.Location = New System.Drawing.Point(650, 484)
        Me.Pieton_B_H_10.Name = "Pieton_B_H_10"
        Me.Pieton_B_H_10.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_B_H_10.Visible = False
        '
        'Pieton_G_G_9
        '
        Me.Pieton_G_G_9.Location = New System.Drawing.Point(626, 477)
        Me.Pieton_G_G_9.Name = "Pieton_G_G_9"
        Me.Pieton_G_G_9.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_G_G_9.Visible = False
        '
        'Pieton_H_B_1
        '
        Me.Pieton_H_B_1.Location = New System.Drawing.Point(649, 261)
        Me.Pieton_H_B_1.Name = "Pieton_H_B_1"
        Me.Pieton_H_B_1.Size = New System.Drawing.Size(8, 7)
        Me.Pieton_H_B_1.Visible = False
        '
        'Pieton_G_G_1
        '
        Me.Pieton_G_G_1.Location = New System.Drawing.Point(627, 267)
        Me.Pieton_G_G_1.Name = "Pieton_G_G_1"
        Me.Pieton_G_G_1.Size = New System.Drawing.Size(8, 7)
        Me.Pieton_G_G_1.Visible = False
        '
        'Pieton_H_H_10
        '
        Me.Pieton_H_H_10.Location = New System.Drawing.Point(651, 247)
        Me.Pieton_H_H_10.Name = "Pieton_H_H_10"
        Me.Pieton_H_H_10.Size = New System.Drawing.Size(8, 7)
        Me.Pieton_H_H_10.Visible = False
        '
        'Pieton_G_D_9
        '
        Me.Pieton_G_D_9.Location = New System.Drawing.Point(640, 266)
        Me.Pieton_G_D_9.Name = "Pieton_G_D_9"
        Me.Pieton_G_D_9.Size = New System.Drawing.Size(8, 7)
        Me.Pieton_G_D_9.Visible = False
        '
        'Pieton_D_G_1
        '
        Me.Pieton_D_G_1.Location = New System.Drawing.Point(911, 270)
        Me.Pieton_D_G_1.Name = "Pieton_D_G_1"
        Me.Pieton_D_G_1.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_D_G_1.Visible = False
        '
        'Pieton_H_B_10
        '
        Me.Pieton_H_B_10.Location = New System.Drawing.Point(903, 262)
        Me.Pieton_H_B_10.Name = "Pieton_H_B_10"
        Me.Pieton_H_B_10.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_H_B_10.Visible = False
        '
        'Pieton_D_D_9
        '
        Me.Pieton_D_D_9.Location = New System.Drawing.Point(926, 269)
        Me.Pieton_D_D_9.Name = "Pieton_D_D_9"
        Me.Pieton_D_D_9.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_D_D_9.Visible = False
        '
        'Pieton_H_H_1
        '
        Me.Pieton_H_H_1.Location = New System.Drawing.Point(904, 247)
        Me.Pieton_H_H_1.Name = "Pieton_H_H_1"
        Me.Pieton_H_H_1.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_H_H_1.Visible = False
        '
        'Pieton_B_B_10
        '
        Me.Pieton_B_B_10.Location = New System.Drawing.Point(904, 499)
        Me.Pieton_B_B_10.Name = "Pieton_B_B_10"
        Me.Pieton_B_B_10.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_B_B_10.Visible = False
        '
        'Pieton_B_H_1
        '
        Me.Pieton_B_H_1.Location = New System.Drawing.Point(903, 484)
        Me.Pieton_B_H_1.Name = "Pieton_B_H_1"
        Me.Pieton_B_H_1.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_B_H_1.Visible = False
        '
        'Pieton_D_D_1
        '
        Me.Pieton_D_D_1.Location = New System.Drawing.Point(927, 479)
        Me.Pieton_D_D_1.Name = "Pieton_D_D_1"
        Me.Pieton_D_D_1.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_D_D_1.Visible = False
        '
        'Pieton_D_G_9
        '
        Me.Pieton_D_G_9.Location = New System.Drawing.Point(913, 479)
        Me.Pieton_D_G_9.Name = "Pieton_D_G_9"
        Me.Pieton_D_G_9.Size = New System.Drawing.Size(8, 8)
        Me.Pieton_D_G_9.Visible = False
        '
        'RectangleShape11
        '
        Me.RectangleShape11.Location = New System.Drawing.Point(662, 472)
        Me.RectangleShape11.Name = "RectangleShape11"
        Me.RectangleShape11.Size = New System.Drawing.Size(21, 42)
        '
        'RectangleShape12
        '
        Me.RectangleShape12.Location = New System.Drawing.Point(880, 473)
        Me.RectangleShape12.Name = "RectangleShape12"
        Me.RectangleShape12.Size = New System.Drawing.Size(21, 42)
        '
        'RectangleShape10
        '
        Me.RectangleShape10.Location = New System.Drawing.Point(880, 241)
        Me.RectangleShape10.Name = "RectangleShape10"
        Me.RectangleShape10.Size = New System.Drawing.Size(21, 42)
        '
        'RectangleShape9
        '
        Me.RectangleShape9.Location = New System.Drawing.Point(662, 242)
        Me.RectangleShape9.Name = "RectangleShape9"
        Me.RectangleShape9.Size = New System.Drawing.Size(21, 42)
        '
        'RectangleShape8
        '
        Me.RectangleShape8.Location = New System.Drawing.Point(621, 279)
        Me.RectangleShape8.Name = "RectangleShape8"
        Me.RectangleShape8.Size = New System.Drawing.Size(38, 20)
        '
        'RectangleShape7
        '
        Me.RectangleShape7.Location = New System.Drawing.Point(622, 456)
        Me.RectangleShape7.Name = "RectangleShape7"
        Me.RectangleShape7.Size = New System.Drawing.Size(38, 20)
        '
        'RectangleShape6
        '
        Me.RectangleShape6.Location = New System.Drawing.Point(904, 457)
        Me.RectangleShape6.Name = "RectangleShape6"
        Me.RectangleShape6.Size = New System.Drawing.Size(38, 20)
        '
        'RectangleShape5
        '
        Me.RectangleShape5.Location = New System.Drawing.Point(904, 280)
        Me.RectangleShape5.Name = "RectangleShape5"
        Me.RectangleShape5.Size = New System.Drawing.Size(38, 20)
        '
        'Voiture_H_6
        '
        Me.Voiture_H_6.Location = New System.Drawing.Point(691, 421)
        Me.Voiture_H_6.Name = "Voiture_H_6"
        Me.Voiture_H_6.Size = New System.Drawing.Size(24, 65)
        Me.Voiture_H_6.Visible = False
        '
        'Voiture_H_7
        '
        Me.Voiture_H_7.Location = New System.Drawing.Point(689, 516)
        Me.Voiture_H_7.Name = "Voiture_H_7"
        Me.Voiture_H_7.Size = New System.Drawing.Size(24, 66)
        Me.Voiture_H_7.Visible = False
        '
        'Voiture_B_8
        '
        Me.Voiture_B_8.Location = New System.Drawing.Point(846, 4)
        Me.Voiture_B_8.Name = "Voiture_B_8"
        Me.Voiture_B_8.Size = New System.Drawing.Size(24, 66)
        Me.Voiture_B_8.Visible = False
        '
        'Voiture_B_7
        '
        Me.Voiture_B_7.Location = New System.Drawing.Point(844, 81)
        Me.Voiture_B_7.Name = "Voiture_B_7"
        Me.Voiture_B_7.Size = New System.Drawing.Size(24, 66)
        Me.Voiture_B_7.Visible = False
        '
        'Voiture_B_6
        '
        Me.Voiture_B_6.Location = New System.Drawing.Point(847, 161)
        Me.Voiture_B_6.Name = "Voiture_B_6"
        Me.Voiture_B_6.Size = New System.Drawing.Size(24, 66)
        Me.Voiture_B_6.Visible = False
        '
        'Voiture_B_5
        '
        Me.Voiture_B_5.Location = New System.Drawing.Point(847, 241)
        Me.Voiture_B_5.Name = "Voiture_B_5"
        Me.Voiture_B_5.Size = New System.Drawing.Size(24, 66)
        Me.Voiture_B_5.Visible = False
        '
        'Voiture_B_4
        '
        Me.Voiture_B_4.Location = New System.Drawing.Point(847, 339)
        Me.Voiture_B_4.Name = "Voiture_B_4"
        Me.Voiture_B_4.Size = New System.Drawing.Size(24, 66)
        Me.Voiture_B_4.Visible = False
        '
        'Voiture_B_3
        '
        Me.Voiture_B_3.Location = New System.Drawing.Point(849, 425)
        Me.Voiture_B_3.Name = "Voiture_B_3"
        Me.Voiture_B_3.Size = New System.Drawing.Size(25, 66)
        Me.Voiture_B_3.Visible = False
        '
        'Voiture_H_8
        '
        Me.Voiture_H_8.Location = New System.Drawing.Point(692, 591)
        Me.Voiture_H_8.Name = "Voiture_H_8"
        Me.Voiture_H_8.Size = New System.Drawing.Size(24, 66)
        Me.Voiture_H_8.Visible = False
        '
        'Voiture_B_2
        '
        Me.Voiture_B_2.Location = New System.Drawing.Point(850, 515)
        Me.Voiture_B_2.Name = "Voiture_B_2"
        Me.Voiture_B_2.Size = New System.Drawing.Size(24, 66)
        Me.Voiture_B_2.Visible = False
        '
        'Voiture_H_5
        '
        Me.Voiture_H_5.Location = New System.Drawing.Point(690, 336)
        Me.Voiture_H_5.Name = "Voiture_H_5"
        Me.Voiture_H_5.Size = New System.Drawing.Size(24, 66)
        Me.Voiture_H_5.Visible = False
        '
        'Voiture_H_4
        '
        Me.Voiture_H_4.Location = New System.Drawing.Point(687, 240)
        Me.Voiture_H_4.Name = "Voiture_H_4"
        Me.Voiture_H_4.Size = New System.Drawing.Size(24, 66)
        Me.Voiture_H_4.Visible = False
        '
        'Voiture_H_3
        '
        Me.Voiture_H_3.Location = New System.Drawing.Point(688, 160)
        Me.Voiture_H_3.Name = "Voiture_H_3"
        Me.Voiture_H_3.Size = New System.Drawing.Size(24, 66)
        Me.Voiture_H_3.Visible = False
        '
        'Voiture_H_2
        '
        Me.Voiture_H_2.Location = New System.Drawing.Point(690, 79)
        Me.Voiture_H_2.Name = "Voiture_H_2"
        Me.Voiture_H_2.Size = New System.Drawing.Size(24, 66)
        Me.Voiture_H_2.Visible = False
        '
        'Voiture_D_9
        '
        Me.Voiture_D_9.Location = New System.Drawing.Point(532, 308)
        Me.Voiture_D_9.Name = "Voiture_D_9"
        Me.Voiture_D_9.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_D_9.Visible = False
        '
        'Voiture_D_11
        '
        Me.Voiture_D_11.Location = New System.Drawing.Point(370, 310)
        Me.Voiture_D_11.Name = "Voiture_D_11"
        Me.Voiture_D_11.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_D_11.Visible = False
        '
        'Voiture_D_10
        '
        Me.Voiture_D_10.Location = New System.Drawing.Point(452, 309)
        Me.Voiture_D_10.Name = "Voiture_D_10"
        Me.Voiture_D_10.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_D_10.Visible = False
        '
        'Voiture_D_8
        '
        Me.Voiture_D_8.Location = New System.Drawing.Point(611, 306)
        Me.Voiture_D_8.Name = "Voiture_D_8"
        Me.Voiture_D_8.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_D_8.Visible = False
        '
        'Voiture_D_7
        '
        Me.Voiture_D_7.Location = New System.Drawing.Point(696, 308)
        Me.Voiture_D_7.Name = "Voiture_D_7"
        Me.Voiture_D_7.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_D_7.Visible = False
        '
        'Voiture_D_6
        '
        Me.Voiture_D_6.Location = New System.Drawing.Point(780, 309)
        Me.Voiture_D_6.Name = "Voiture_D_6"
        Me.Voiture_D_6.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_D_6.Visible = False
        '
        'Voiture_G_6
        '
        Me.Voiture_G_6.Location = New System.Drawing.Point(787, 423)
        Me.Voiture_G_6.Name = "Voiture_G_6"
        Me.Voiture_G_6.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_G_6.Visible = False
        '
        'Voiture_D_5
        '
        Me.Voiture_D_5.Location = New System.Drawing.Point(860, 309)
        Me.Voiture_D_5.Name = "Voiture_D_5"
        Me.Voiture_D_5.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_D_5.Visible = False
        '
        'Voiture_G_9
        '
        Me.Voiture_G_9.Location = New System.Drawing.Point(1036, 420)
        Me.Voiture_G_9.Name = "Voiture_G_9"
        Me.Voiture_G_9.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_G_9.Visible = False
        '
        'Voiture_G_10
        '
        Me.Voiture_G_10.Location = New System.Drawing.Point(1125, 419)
        Me.Voiture_G_10.Name = "Voiture_G_10"
        Me.Voiture_G_10.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_G_10.Visible = False
        '
        'Voiture_G_11
        '
        Me.Voiture_G_11.Location = New System.Drawing.Point(1221, 423)
        Me.Voiture_G_11.Name = "Voiture_G_11"
        Me.Voiture_G_11.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_G_11.Visible = False
        '
        'Voiture_G_8
        '
        Me.Voiture_G_8.Location = New System.Drawing.Point(952, 421)
        Me.Voiture_G_8.Name = "Voiture_G_8"
        Me.Voiture_G_8.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_G_8.Visible = False
        '
        'Voiture_D_4
        '
        Me.Voiture_D_4.Location = New System.Drawing.Point(945, 308)
        Me.Voiture_D_4.Name = "Voiture_D_4"
        Me.Voiture_D_4.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_D_4.Visible = False
        '
        'Voiture_D_3
        '
        Me.Voiture_D_3.Location = New System.Drawing.Point(1027, 309)
        Me.Voiture_D_3.Name = "Voiture_D_3"
        Me.Voiture_D_3.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_D_3.Visible = False
        '
        'Voiture_D_2
        '
        Me.Voiture_D_2.Location = New System.Drawing.Point(1118, 310)
        Me.Voiture_D_2.Name = "Voiture_D_2"
        Me.Voiture_D_2.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_D_2.Visible = False
        '
        'Voiture_G_7
        '
        Me.Voiture_G_7.Location = New System.Drawing.Point(870, 420)
        Me.Voiture_G_7.Name = "Voiture_G_7"
        Me.Voiture_G_7.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_G_7.Visible = False
        '
        'Voiture_G_5
        '
        Me.Voiture_G_5.Location = New System.Drawing.Point(704, 425)
        Me.Voiture_G_5.Name = "Voiture_G_5"
        Me.Voiture_G_5.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_G_5.Visible = False
        '
        'Voiture_G_4
        '
        Me.Voiture_G_4.Location = New System.Drawing.Point(620, 426)
        Me.Voiture_G_4.Name = "Voiture_G_4"
        Me.Voiture_G_4.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_G_4.Visible = False
        '
        'Voiture_G_3
        '
        Me.Voiture_G_3.Location = New System.Drawing.Point(539, 425)
        Me.Voiture_G_3.Name = "Voiture_G_3"
        Me.Voiture_G_3.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_G_3.Visible = False
        '
        'Voiture_G_2
        '
        Me.Voiture_G_2.Location = New System.Drawing.Point(456, 425)
        Me.Voiture_G_2.Name = "Voiture_G_2"
        Me.Voiture_G_2.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_G_2.Visible = False
        '
        'Voiture_H_1
        '
        Me.Voiture_H_1.Location = New System.Drawing.Point(693, 8)
        Me.Voiture_H_1.Name = "Voiture_H_1"
        Me.Voiture_H_1.Size = New System.Drawing.Size(24, 66)
        Me.Voiture_H_1.Visible = False
        '
        'Voiture_B_1
        '
        Me.Voiture_B_1.Location = New System.Drawing.Point(849, 588)
        Me.Voiture_B_1.Name = "Voiture_B_1"
        Me.Voiture_B_1.Size = New System.Drawing.Size(24, 66)
        Me.Voiture_B_1.Visible = False
        '
        'Voiture_D_1
        '
        Me.Voiture_D_1.Location = New System.Drawing.Point(1213, 311)
        Me.Voiture_D_1.Name = "Voiture_D_1"
        Me.Voiture_D_1.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_D_1.Visible = False
        '
        'Voiture_G_1
        '
        Me.Voiture_G_1.Location = New System.Drawing.Point(369, 426)
        Me.Voiture_G_1.Name = "Voiture_G_1"
        Me.Voiture_G_1.Size = New System.Drawing.Size(75, 23)
        Me.Voiture_G_1.Visible = False
        '
        'RectangleShape4
        '
        Me.RectangleShape4.Location = New System.Drawing.Point(641, 95)
        Me.RectangleShape4.Name = "RectangleShape4"
        Me.RectangleShape4.Size = New System.Drawing.Size(40, 105)
        '
        'RectangleShape3
        '
        Me.RectangleShape3.Location = New System.Drawing.Point(892, 549)
        Me.RectangleShape3.Name = "RectangleShape3"
        Me.RectangleShape3.Size = New System.Drawing.Size(48, 83)
        '
        'RectangleShape2
        '
        Me.RectangleShape2.Location = New System.Drawing.Point(373, 461)
        Me.RectangleShape2.Name = "RectangleShape2"
        Me.RectangleShape2.Size = New System.Drawing.Size(118, 57)
        '
        'RectangleShape1
        '
        Me.RectangleShape1.Location = New System.Drawing.Point(1005, 244)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(141, 55)
        '
        'LineShape8
        '
        Me.LineShape8.Name = "LineShape8"
        Me.LineShape8.X1 = 685
        Me.LineShape8.X2 = 682
        Me.LineShape8.Y1 = 452
        Me.LineShape8.Y2 = 665
        '
        'LineShape7
        '
        Me.LineShape7.Name = "LineShape7"
        Me.LineShape7.X1 = 880
        Me.LineShape7.X2 = 877
        Me.LineShape7.Y1 = 454
        Me.LineShape7.Y2 = 665
        '
        'LineShape6
        '
        Me.LineShape6.Name = "LineShape6"
        Me.LineShape6.X1 = 881
        Me.LineShape6.X2 = 880
        Me.LineShape6.Y1 = 6
        Me.LineShape6.Y2 = 303
        '
        'LineShape5
        '
        Me.LineShape5.Name = "LineShape5"
        Me.LineShape5.X1 = 686
        Me.LineShape5.X2 = 685
        Me.LineShape5.Y1 = 6
        Me.LineShape5.Y2 = 298
        '
        'LineShape4
        '
        Me.LineShape4.Name = "LineShape4"
        Me.LineShape4.X1 = 362
        Me.LineShape4.X2 = 683
        Me.LineShape4.Y1 = 455
        Me.LineShape4.Y2 = 453
        '
        'LineShape3
        '
        Me.LineShape3.Name = "LineShape3"
        Me.LineShape3.X1 = 361
        Me.LineShape3.X2 = 685
        Me.LineShape3.Y1 = 303
        Me.LineShape3.Y2 = 300
        '
        'LineShape2
        '
        Me.LineShape2.Name = "LineShape2"
        Me.LineShape2.X1 = 881
        Me.LineShape2.X2 = 1278
        Me.LineShape2.Y1 = 454
        Me.LineShape2.Y2 = 450
        '
        'LineShape1
        '
        Me.LineShape1.Name = "LineShape1"
        Me.LineShape1.X1 = 881
        Me.LineShape1.X2 = 1287
        Me.LineShape1.Y1 = 302
        Me.LineShape1.Y2 = 302
        '
        'Temps_Feu_Rouge
        '
        Me.Temps_Feu_Rouge.AutoSize = True
        Me.Temps_Feu_Rouge.Location = New System.Drawing.Point(3, 112)
        Me.Temps_Feu_Rouge.Name = "Temps_Feu_Rouge"
        Me.Temps_Feu_Rouge.Size = New System.Drawing.Size(116, 13)
        Me.Temps_Feu_Rouge.TabIndex = 20
        Me.Temps_Feu_Rouge.Text = "Temps du Feu Rouge :"
        '
        'Temps_Feu_Vert
        '
        Me.Temps_Feu_Vert.AutoSize = True
        Me.Temps_Feu_Vert.Location = New System.Drawing.Point(6, 142)
        Me.Temps_Feu_Vert.Name = "Temps_Feu_Vert"
        Me.Temps_Feu_Vert.Size = New System.Drawing.Size(103, 13)
        Me.Temps_Feu_Vert.TabIndex = 21
        Me.Temps_Feu_Vert.Text = "Temps du Feu Vert :"
        '
        'Temps_Feu_Orange
        '
        Me.Temps_Feu_Orange.AutoSize = True
        Me.Temps_Feu_Orange.Location = New System.Drawing.Point(6, 176)
        Me.Temps_Feu_Orange.Name = "Temps_Feu_Orange"
        Me.Temps_Feu_Orange.Size = New System.Drawing.Size(119, 13)
        Me.Temps_Feu_Orange.TabIndex = 22
        Me.Temps_Feu_Orange.Text = "Temps du Feu Orange :"
        '
        'Feu_Rouge_Voie_A_1
        '
        Me.Feu_Rouge_Voie_A_1.ErrorImage = Nothing
        Me.Feu_Rouge_Voie_A_1.InitialImage = Nothing
        Me.Feu_Rouge_Voie_A_1.Location = New System.Drawing.Point(645, 167)
        Me.Feu_Rouge_Voie_A_1.Name = "Feu_Rouge_Voie_A_1"
        Me.Feu_Rouge_Voie_A_1.Size = New System.Drawing.Size(33, 28)
        Me.Feu_Rouge_Voie_A_1.TabIndex = 4
        Me.Feu_Rouge_Voie_A_1.TabStop = False
        '
        'Feu_Vert_Voie_A_1
        '
        Me.Feu_Vert_Voie_A_1.ErrorImage = Nothing
        Me.Feu_Vert_Voie_A_1.InitialImage = Nothing
        Me.Feu_Vert_Voie_A_1.Location = New System.Drawing.Point(645, 99)
        Me.Feu_Vert_Voie_A_1.Name = "Feu_Vert_Voie_A_1"
        Me.Feu_Vert_Voie_A_1.Size = New System.Drawing.Size(33, 36)
        Me.Feu_Vert_Voie_A_1.TabIndex = 2
        Me.Feu_Vert_Voie_A_1.TabStop = False
        '
        'Feu_Orange_Voie_A_1
        '
        Me.Feu_Orange_Voie_A_1.ErrorImage = Nothing
        Me.Feu_Orange_Voie_A_1.InitialImage = Nothing
        Me.Feu_Orange_Voie_A_1.Location = New System.Drawing.Point(645, 133)
        Me.Feu_Orange_Voie_A_1.Name = "Feu_Orange_Voie_A_1"
        Me.Feu_Orange_Voie_A_1.Size = New System.Drawing.Size(33, 36)
        Me.Feu_Orange_Voie_A_1.TabIndex = 3
        Me.Feu_Orange_Voie_A_1.TabStop = False
        '
        'Feu_Orange_Voie_B_1
        '
        Me.Feu_Orange_Voie_B_1.ErrorImage = Nothing
        Me.Feu_Orange_Voie_B_1.InitialImage = Nothing
        Me.Feu_Orange_Voie_B_1.Location = New System.Drawing.Point(1053, 247)
        Me.Feu_Orange_Voie_B_1.Name = "Feu_Orange_Voie_B_1"
        Me.Feu_Orange_Voie_B_1.Size = New System.Drawing.Size(50, 52)
        Me.Feu_Orange_Voie_B_1.TabIndex = 6
        Me.Feu_Orange_Voie_B_1.TabStop = False
        '
        'Feu_Vert_Voie_B_1
        '
        Me.Feu_Vert_Voie_B_1.ErrorImage = Nothing
        Me.Feu_Vert_Voie_B_1.InitialImage = Nothing
        Me.Feu_Vert_Voie_B_1.Location = New System.Drawing.Point(1103, 247)
        Me.Feu_Vert_Voie_B_1.Name = "Feu_Vert_Voie_B_1"
        Me.Feu_Vert_Voie_B_1.Size = New System.Drawing.Size(42, 52)
        Me.Feu_Vert_Voie_B_1.TabIndex = 5
        Me.Feu_Vert_Voie_B_1.TabStop = False
        '
        'Feu_Orange_Voie_A_2
        '
        Me.Feu_Orange_Voie_A_2.ErrorImage = Nothing
        Me.Feu_Orange_Voie_A_2.InitialImage = Nothing
        Me.Feu_Orange_Voie_A_2.Location = New System.Drawing.Point(895, 577)
        Me.Feu_Orange_Voie_A_2.Name = "Feu_Orange_Voie_A_2"
        Me.Feu_Orange_Voie_A_2.Size = New System.Drawing.Size(43, 26)
        Me.Feu_Orange_Voie_A_2.TabIndex = 9
        Me.Feu_Orange_Voie_A_2.TabStop = False
        '
        'Feu_Vert_Voie_A_2
        '
        Me.Feu_Vert_Voie_A_2.ErrorImage = Nothing
        Me.Feu_Vert_Voie_A_2.InitialImage = Nothing
        Me.Feu_Vert_Voie_A_2.Location = New System.Drawing.Point(895, 604)
        Me.Feu_Vert_Voie_A_2.Name = "Feu_Vert_Voie_A_2"
        Me.Feu_Vert_Voie_A_2.Size = New System.Drawing.Size(43, 27)
        Me.Feu_Vert_Voie_A_2.TabIndex = 10
        Me.Feu_Vert_Voie_A_2.TabStop = False
        '
        'Feu_Vert_Voie_B_2
        '
        Me.Feu_Vert_Voie_B_2.ErrorImage = Nothing
        Me.Feu_Vert_Voie_B_2.InitialImage = Nothing
        Me.Feu_Vert_Voie_B_2.Location = New System.Drawing.Point(378, 465)
        Me.Feu_Vert_Voie_B_2.Name = "Feu_Vert_Voie_B_2"
        Me.Feu_Vert_Voie_B_2.Size = New System.Drawing.Size(35, 49)
        Me.Feu_Vert_Voie_B_2.TabIndex = 13
        Me.Feu_Vert_Voie_B_2.TabStop = False
        '
        'Feu_Orange_Voie_B_2
        '
        Me.Feu_Orange_Voie_B_2.ErrorImage = Nothing
        Me.Feu_Orange_Voie_B_2.InitialImage = Nothing
        Me.Feu_Orange_Voie_B_2.Location = New System.Drawing.Point(410, 465)
        Me.Feu_Orange_Voie_B_2.Name = "Feu_Orange_Voie_B_2"
        Me.Feu_Orange_Voie_B_2.Size = New System.Drawing.Size(39, 49)
        Me.Feu_Orange_Voie_B_2.TabIndex = 12
        Me.Feu_Orange_Voie_B_2.TabStop = False
        '
        'Pieton_Feu_Vert_B_1_1
        '
        Me.Pieton_Feu_Vert_B_1_1.ErrorImage = Nothing
        Me.Pieton_Feu_Vert_B_1_1.InitialImage = Nothing
        Me.Pieton_Feu_Vert_B_1_1.Location = New System.Drawing.Point(624, 280)
        Me.Pieton_Feu_Vert_B_1_1.Name = "Pieton_Feu_Vert_B_1_1"
        Me.Pieton_Feu_Vert_B_1_1.Size = New System.Drawing.Size(18, 19)
        Me.Pieton_Feu_Vert_B_1_1.TabIndex = 23
        Me.Pieton_Feu_Vert_B_1_1.TabStop = False
        '
        'Pieton_Feu_Rouge_B_1_1
        '
        Me.Pieton_Feu_Rouge_B_1_1.ErrorImage = Nothing
        Me.Pieton_Feu_Rouge_B_1_1.InitialImage = Nothing
        Me.Pieton_Feu_Rouge_B_1_1.Location = New System.Drawing.Point(641, 280)
        Me.Pieton_Feu_Rouge_B_1_1.Name = "Pieton_Feu_Rouge_B_1_1"
        Me.Pieton_Feu_Rouge_B_1_1.Size = New System.Drawing.Size(18, 19)
        Me.Pieton_Feu_Rouge_B_1_1.TabIndex = 24
        Me.Pieton_Feu_Rouge_B_1_1.TabStop = False
        '
        'Pieton_Feu_Rouge_B_1_2
        '
        Me.Pieton_Feu_Rouge_B_1_2.ErrorImage = Nothing
        Me.Pieton_Feu_Rouge_B_1_2.InitialImage = Nothing
        Me.Pieton_Feu_Rouge_B_1_2.Location = New System.Drawing.Point(641, 457)
        Me.Pieton_Feu_Rouge_B_1_2.Name = "Pieton_Feu_Rouge_B_1_2"
        Me.Pieton_Feu_Rouge_B_1_2.Size = New System.Drawing.Size(18, 19)
        Me.Pieton_Feu_Rouge_B_1_2.TabIndex = 26
        Me.Pieton_Feu_Rouge_B_1_2.TabStop = False
        '
        'Pieton_Feu_Vert_B_1_2
        '
        Me.Pieton_Feu_Vert_B_1_2.ErrorImage = Nothing
        Me.Pieton_Feu_Vert_B_1_2.InitialImage = Nothing
        Me.Pieton_Feu_Vert_B_1_2.Location = New System.Drawing.Point(624, 457)
        Me.Pieton_Feu_Vert_B_1_2.Name = "Pieton_Feu_Vert_B_1_2"
        Me.Pieton_Feu_Vert_B_1_2.Size = New System.Drawing.Size(18, 19)
        Me.Pieton_Feu_Vert_B_1_2.TabIndex = 25
        Me.Pieton_Feu_Vert_B_1_2.TabStop = False
        '
        'Pieton_Feu_Vert_B_2_2
        '
        Me.Pieton_Feu_Vert_B_2_2.ErrorImage = Nothing
        Me.Pieton_Feu_Vert_B_2_2.InitialImage = Nothing
        Me.Pieton_Feu_Vert_B_2_2.Location = New System.Drawing.Point(923, 458)
        Me.Pieton_Feu_Vert_B_2_2.Name = "Pieton_Feu_Vert_B_2_2"
        Me.Pieton_Feu_Vert_B_2_2.Size = New System.Drawing.Size(18, 19)
        Me.Pieton_Feu_Vert_B_2_2.TabIndex = 30
        Me.Pieton_Feu_Vert_B_2_2.TabStop = False
        '
        'Pieton_Feu_Rouge_B_2_2
        '
        Me.Pieton_Feu_Rouge_B_2_2.ErrorImage = Nothing
        Me.Pieton_Feu_Rouge_B_2_2.InitialImage = Nothing
        Me.Pieton_Feu_Rouge_B_2_2.Location = New System.Drawing.Point(906, 458)
        Me.Pieton_Feu_Rouge_B_2_2.Name = "Pieton_Feu_Rouge_B_2_2"
        Me.Pieton_Feu_Rouge_B_2_2.Size = New System.Drawing.Size(18, 19)
        Me.Pieton_Feu_Rouge_B_2_2.TabIndex = 29
        Me.Pieton_Feu_Rouge_B_2_2.TabStop = False
        '
        'Pieton_Feu_Vert_B_2_1
        '
        Me.Pieton_Feu_Vert_B_2_1.ErrorImage = Nothing
        Me.Pieton_Feu_Vert_B_2_1.InitialImage = Nothing
        Me.Pieton_Feu_Vert_B_2_1.Location = New System.Drawing.Point(923, 281)
        Me.Pieton_Feu_Vert_B_2_1.Name = "Pieton_Feu_Vert_B_2_1"
        Me.Pieton_Feu_Vert_B_2_1.Size = New System.Drawing.Size(18, 19)
        Me.Pieton_Feu_Vert_B_2_1.TabIndex = 28
        Me.Pieton_Feu_Vert_B_2_1.TabStop = False
        '
        'Pieton_Feu_Rouge_B_2_1
        '
        Me.Pieton_Feu_Rouge_B_2_1.ErrorImage = Nothing
        Me.Pieton_Feu_Rouge_B_2_1.InitialImage = Nothing
        Me.Pieton_Feu_Rouge_B_2_1.Location = New System.Drawing.Point(906, 281)
        Me.Pieton_Feu_Rouge_B_2_1.Name = "Pieton_Feu_Rouge_B_2_1"
        Me.Pieton_Feu_Rouge_B_2_1.Size = New System.Drawing.Size(18, 19)
        Me.Pieton_Feu_Rouge_B_2_1.TabIndex = 27
        Me.Pieton_Feu_Rouge_B_2_1.TabStop = False
        '
        'Pieton_Feu_Rouge_A_2_2
        '
        Me.Pieton_Feu_Rouge_A_2_2.ErrorImage = Nothing
        Me.Pieton_Feu_Rouge_A_2_2.InitialImage = Nothing
        Me.Pieton_Feu_Rouge_A_2_2.Location = New System.Drawing.Point(882, 264)
        Me.Pieton_Feu_Rouge_A_2_2.Name = "Pieton_Feu_Rouge_A_2_2"
        Me.Pieton_Feu_Rouge_A_2_2.Size = New System.Drawing.Size(18, 19)
        Me.Pieton_Feu_Rouge_A_2_2.TabIndex = 31
        Me.Pieton_Feu_Rouge_A_2_2.TabStop = False
        '
        'Pieton_Feu_Vert_A_2_2
        '
        Me.Pieton_Feu_Vert_A_2_2.ErrorImage = Nothing
        Me.Pieton_Feu_Vert_A_2_2.InitialImage = Nothing
        Me.Pieton_Feu_Vert_A_2_2.Location = New System.Drawing.Point(882, 244)
        Me.Pieton_Feu_Vert_A_2_2.Name = "Pieton_Feu_Vert_A_2_2"
        Me.Pieton_Feu_Vert_A_2_2.Size = New System.Drawing.Size(18, 19)
        Me.Pieton_Feu_Vert_A_2_2.TabIndex = 32
        Me.Pieton_Feu_Vert_A_2_2.TabStop = False
        '
        'Pieton_Feu_Vert_A_2_1
        '
        Me.Pieton_Feu_Vert_A_2_1.ErrorImage = Nothing
        Me.Pieton_Feu_Vert_A_2_1.InitialImage = Nothing
        Me.Pieton_Feu_Vert_A_2_1.Location = New System.Drawing.Point(664, 244)
        Me.Pieton_Feu_Vert_A_2_1.Name = "Pieton_Feu_Vert_A_2_1"
        Me.Pieton_Feu_Vert_A_2_1.Size = New System.Drawing.Size(18, 19)
        Me.Pieton_Feu_Vert_A_2_1.TabIndex = 34
        Me.Pieton_Feu_Vert_A_2_1.TabStop = False
        '
        'Pieton_Feu_Rouge_A_2_1
        '
        Me.Pieton_Feu_Rouge_A_2_1.ErrorImage = Nothing
        Me.Pieton_Feu_Rouge_A_2_1.InitialImage = Nothing
        Me.Pieton_Feu_Rouge_A_2_1.Location = New System.Drawing.Point(664, 264)
        Me.Pieton_Feu_Rouge_A_2_1.Name = "Pieton_Feu_Rouge_A_2_1"
        Me.Pieton_Feu_Rouge_A_2_1.Size = New System.Drawing.Size(18, 19)
        Me.Pieton_Feu_Rouge_A_2_1.TabIndex = 33
        Me.Pieton_Feu_Rouge_A_2_1.TabStop = False
        '
        'Pieton_Feu_Rouge_A_1_2
        '
        Me.Pieton_Feu_Rouge_A_1_2.ErrorImage = Nothing
        Me.Pieton_Feu_Rouge_A_1_2.InitialImage = Nothing
        Me.Pieton_Feu_Rouge_A_1_2.Location = New System.Drawing.Point(664, 475)
        Me.Pieton_Feu_Rouge_A_1_2.Name = "Pieton_Feu_Rouge_A_1_2"
        Me.Pieton_Feu_Rouge_A_1_2.Size = New System.Drawing.Size(18, 19)
        Me.Pieton_Feu_Rouge_A_1_2.TabIndex = 38
        Me.Pieton_Feu_Rouge_A_1_2.TabStop = False
        '
        'Pieton_Feu_Vert_A_1_2
        '
        Me.Pieton_Feu_Vert_A_1_2.ErrorImage = Nothing
        Me.Pieton_Feu_Vert_A_1_2.InitialImage = Nothing
        Me.Pieton_Feu_Vert_A_1_2.Location = New System.Drawing.Point(664, 495)
        Me.Pieton_Feu_Vert_A_1_2.Name = "Pieton_Feu_Vert_A_1_2"
        Me.Pieton_Feu_Vert_A_1_2.Size = New System.Drawing.Size(18, 19)
        Me.Pieton_Feu_Vert_A_1_2.TabIndex = 37
        Me.Pieton_Feu_Vert_A_1_2.TabStop = False
        '
        'Pieton_Feu_Rouge_A_1_1
        '
        Me.Pieton_Feu_Rouge_A_1_1.ErrorImage = Nothing
        Me.Pieton_Feu_Rouge_A_1_1.InitialImage = Nothing
        Me.Pieton_Feu_Rouge_A_1_1.Location = New System.Drawing.Point(882, 475)
        Me.Pieton_Feu_Rouge_A_1_1.Name = "Pieton_Feu_Rouge_A_1_1"
        Me.Pieton_Feu_Rouge_A_1_1.Size = New System.Drawing.Size(18, 19)
        Me.Pieton_Feu_Rouge_A_1_1.TabIndex = 36
        Me.Pieton_Feu_Rouge_A_1_1.TabStop = False
        '
        'Pieton_Feu_Vert_A_1_1
        '
        Me.Pieton_Feu_Vert_A_1_1.ErrorImage = Nothing
        Me.Pieton_Feu_Vert_A_1_1.InitialImage = Nothing
        Me.Pieton_Feu_Vert_A_1_1.Location = New System.Drawing.Point(882, 495)
        Me.Pieton_Feu_Vert_A_1_1.Name = "Pieton_Feu_Vert_A_1_1"
        Me.Pieton_Feu_Vert_A_1_1.Size = New System.Drawing.Size(18, 19)
        Me.Pieton_Feu_Vert_A_1_1.TabIndex = 35
        Me.Pieton_Feu_Vert_A_1_1.TabStop = False
        '
        'Nombre_Voiture_B
        '
        Me.Nombre_Voiture_B.FormattingEnabled = True
        Me.Nombre_Voiture_B.Items.AddRange(New Object() {"0", "1", "2"})
        Me.Nombre_Voiture_B.Location = New System.Drawing.Point(895, 649)
        Me.Nombre_Voiture_B.Name = "Nombre_Voiture_B"
        Me.Nombre_Voiture_B.Size = New System.Drawing.Size(29, 21)
        Me.Nombre_Voiture_B.TabIndex = 39
        '
        'Nombre_Voiture_G
        '
        Me.Nombre_Voiture_G.FormattingEnabled = True
        Me.Nombre_Voiture_G.Items.AddRange(New Object() {"0", "1", "2", "3"})
        Me.Nombre_Voiture_G.Location = New System.Drawing.Point(309, 461)
        Me.Nombre_Voiture_G.Name = "Nombre_Voiture_G"
        Me.Nombre_Voiture_G.Size = New System.Drawing.Size(29, 21)
        Me.Nombre_Voiture_G.TabIndex = 40
        '
        'Nombre_Voiture_D
        '
        Me.Nombre_Voiture_D.FormattingEnabled = True
        Me.Nombre_Voiture_D.Items.AddRange(New Object() {"0", "1", "2", "3"})
        Me.Nombre_Voiture_D.Location = New System.Drawing.Point(1324, 278)
        Me.Nombre_Voiture_D.Name = "Nombre_Voiture_D"
        Me.Nombre_Voiture_D.Size = New System.Drawing.Size(29, 21)
        Me.Nombre_Voiture_D.TabIndex = 41
        '
        'Nombre_Voiture_H
        '
        Me.Nombre_Voiture_H.FormattingEnabled = True
        Me.Nombre_Voiture_H.Items.AddRange(New Object() {"0", "1", "2", "3"})
        Me.Nombre_Voiture_H.Location = New System.Drawing.Point(649, 12)
        Me.Nombre_Voiture_H.Name = "Nombre_Voiture_H"
        Me.Nombre_Voiture_H.Size = New System.Drawing.Size(29, 21)
        Me.Nombre_Voiture_H.TabIndex = 42
        '
        'Nombre_Pietons_GG
        '
        Me.Nombre_Pietons_GG.FormattingEnabled = True
        Me.Nombre_Pietons_GG.Items.AddRange(New Object() {"0", "1"})
        Me.Nombre_Pietons_GG.Location = New System.Drawing.Point(586, 248)
        Me.Nombre_Pietons_GG.Name = "Nombre_Pietons_GG"
        Me.Nombre_Pietons_GG.Size = New System.Drawing.Size(29, 21)
        Me.Nombre_Pietons_GG.TabIndex = 43
        '
        'Nombre_Pietons_HB
        '
        Me.Nombre_Pietons_HB.FormattingEnabled = True
        Me.Nombre_Pietons_HB.Items.AddRange(New Object() {"0", "1"})
        Me.Nombre_Pietons_HB.Location = New System.Drawing.Point(626, 217)
        Me.Nombre_Pietons_HB.Name = "Nombre_Pietons_HB"
        Me.Nombre_Pietons_HB.Size = New System.Drawing.Size(29, 21)
        Me.Nombre_Pietons_HB.TabIndex = 44
        '
        'Nombre_Pietons_BB
        '
        Me.Nombre_Pietons_BB.FormattingEnabled = True
        Me.Nombre_Pietons_BB.Items.AddRange(New Object() {"0", "1"})
        Me.Nombre_Pietons_BB.Location = New System.Drawing.Point(626, 515)
        Me.Nombre_Pietons_BB.Name = "Nombre_Pietons_BB"
        Me.Nombre_Pietons_BB.Size = New System.Drawing.Size(29, 21)
        Me.Nombre_Pietons_BB.TabIndex = 45
        '
        'Nombre_Pietons_BH
        '
        Me.Nombre_Pietons_BH.FormattingEnabled = True
        Me.Nombre_Pietons_BH.Items.AddRange(New Object() {"0", "1"})
        Me.Nombre_Pietons_BH.Location = New System.Drawing.Point(917, 515)
        Me.Nombre_Pietons_BH.Name = "Nombre_Pietons_BH"
        Me.Nombre_Pietons_BH.Size = New System.Drawing.Size(29, 21)
        Me.Nombre_Pietons_BH.TabIndex = 46
        '
        'Nombre_Pietons_HH
        '
        Me.Nombre_Pietons_HH.FormattingEnabled = True
        Me.Nombre_Pietons_HH.Items.AddRange(New Object() {"0", "1"})
        Me.Nombre_Pietons_HH.Location = New System.Drawing.Point(903, 217)
        Me.Nombre_Pietons_HH.Name = "Nombre_Pietons_HH"
        Me.Nombre_Pietons_HH.Size = New System.Drawing.Size(29, 21)
        Me.Nombre_Pietons_HH.TabIndex = 47
        '
        'Nombre_Pietons_DG
        '
        Me.Nombre_Pietons_DG.FormattingEnabled = True
        Me.Nombre_Pietons_DG.Items.AddRange(New Object() {"0", "1"})
        Me.Nombre_Pietons_DG.Location = New System.Drawing.Point(945, 248)
        Me.Nombre_Pietons_DG.Name = "Nombre_Pietons_DG"
        Me.Nombre_Pietons_DG.Size = New System.Drawing.Size(29, 21)
        Me.Nombre_Pietons_DG.TabIndex = 48
        '
        'Nombre_Pietons_DD
        '
        Me.Nombre_Pietons_DD.FormattingEnabled = True
        Me.Nombre_Pietons_DD.Items.AddRange(New Object() {"0", "1"})
        Me.Nombre_Pietons_DD.Location = New System.Drawing.Point(945, 481)
        Me.Nombre_Pietons_DD.Name = "Nombre_Pietons_DD"
        Me.Nombre_Pietons_DD.Size = New System.Drawing.Size(29, 21)
        Me.Nombre_Pietons_DD.TabIndex = 49
        '
        'Nombre_Pietons_GD
        '
        Me.Nombre_Pietons_GD.FormattingEnabled = True
        Me.Nombre_Pietons_GD.Items.AddRange(New Object() {"0", "1"})
        Me.Nombre_Pietons_GD.Location = New System.Drawing.Point(586, 480)
        Me.Nombre_Pietons_GD.Name = "Nombre_Pietons_GD"
        Me.Nombre_Pietons_GD.Size = New System.Drawing.Size(29, 21)
        Me.Nombre_Pietons_GD.TabIndex = 50
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1636, 711)
        Me.Controls.Add(Me.Nombre_Pietons_GD)
        Me.Controls.Add(Me.Nombre_Pietons_DD)
        Me.Controls.Add(Me.Nombre_Pietons_DG)
        Me.Controls.Add(Me.Nombre_Pietons_HH)
        Me.Controls.Add(Me.Nombre_Pietons_BH)
        Me.Controls.Add(Me.Nombre_Pietons_BB)
        Me.Controls.Add(Me.Nombre_Pietons_HB)
        Me.Controls.Add(Me.Nombre_Pietons_GG)
        Me.Controls.Add(Me.Nombre_Voiture_H)
        Me.Controls.Add(Me.Nombre_Voiture_D)
        Me.Controls.Add(Me.Nombre_Voiture_G)
        Me.Controls.Add(Me.Nombre_Voiture_B)
        Me.Controls.Add(Me.Pieton_Feu_Rouge_A_1_2)
        Me.Controls.Add(Me.Pieton_Feu_Vert_A_1_2)
        Me.Controls.Add(Me.Pieton_Feu_Rouge_A_1_1)
        Me.Controls.Add(Me.Pieton_Feu_Vert_A_1_1)
        Me.Controls.Add(Me.Pieton_Feu_Vert_A_2_1)
        Me.Controls.Add(Me.Pieton_Feu_Rouge_A_2_1)
        Me.Controls.Add(Me.Pieton_Feu_Vert_A_2_2)
        Me.Controls.Add(Me.Pieton_Feu_Rouge_A_2_2)
        Me.Controls.Add(Me.Pieton_Feu_Vert_B_2_2)
        Me.Controls.Add(Me.Pieton_Feu_Rouge_B_2_2)
        Me.Controls.Add(Me.Pieton_Feu_Vert_B_2_1)
        Me.Controls.Add(Me.Pieton_Feu_Rouge_B_2_1)
        Me.Controls.Add(Me.Pieton_Feu_Rouge_B_1_2)
        Me.Controls.Add(Me.Pieton_Feu_Vert_B_1_2)
        Me.Controls.Add(Me.Pieton_Feu_Rouge_B_1_1)
        Me.Controls.Add(Me.Pieton_Feu_Vert_B_1_1)
        Me.Controls.Add(Me.Temps_Feu_Orange)
        Me.Controls.Add(Me.Temps_Feu_Vert)
        Me.Controls.Add(Me.Temps_Feu_Rouge)
        Me.Controls.Add(Me.Label_Temps)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Feu_Vert_Voie_B_2)
        Me.Controls.Add(Me.Feu_Orange_Voie_B_2)
        Me.Controls.Add(Me.Feu_Rouge_Voie_B_2)
        Me.Controls.Add(Me.Feu_Vert_Voie_A_2)
        Me.Controls.Add(Me.Feu_Orange_Voie_A_2)
        Me.Controls.Add(Me.Feu_Rouge_Voie_A_2)
        Me.Controls.Add(Me.Feu_Rouge_Voie_B_1)
        Me.Controls.Add(Me.Feu_Orange_Voie_B_1)
        Me.Controls.Add(Me.Feu_Vert_Voie_B_1)
        Me.Controls.Add(Me.Feu_Rouge_Voie_A_1)
        Me.Controls.Add(Me.Feu_Orange_Voie_A_1)
        Me.Controls.Add(Me.Feu_Vert_Voie_A_1)
        Me.Controls.Add(Me.Arret)
        Me.Controls.Add(Me.Demarrer)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.Feu_Rouge_Voie_B_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Feu_Rouge_Voie_A_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Feu_Rouge_Voie_B_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Feu_Rouge_Voie_A_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Feu_Vert_Voie_A_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Feu_Orange_Voie_A_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Feu_Orange_Voie_B_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Feu_Vert_Voie_B_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Feu_Orange_Voie_A_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Feu_Vert_Voie_A_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Feu_Vert_Voie_B_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Feu_Orange_Voie_B_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pieton_Feu_Vert_B_1_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pieton_Feu_Rouge_B_1_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pieton_Feu_Rouge_B_1_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pieton_Feu_Vert_B_1_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pieton_Feu_Vert_B_2_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pieton_Feu_Rouge_B_2_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pieton_Feu_Vert_B_2_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pieton_Feu_Rouge_B_2_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pieton_Feu_Rouge_A_2_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pieton_Feu_Vert_A_2_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pieton_Feu_Vert_A_2_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pieton_Feu_Rouge_A_2_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pieton_Feu_Rouge_A_1_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pieton_Feu_Vert_A_1_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pieton_Feu_Rouge_A_1_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pieton_Feu_Vert_A_1_1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Demarrer As System.Windows.Forms.Button
    Friend WithEvents Arret As System.Windows.Forms.Button
    Friend WithEvents Feu_Rouge_Voie_B_1 As System.Windows.Forms.PictureBox
    Friend WithEvents Feu_Rouge_Voie_A_2 As System.Windows.Forms.PictureBox
    Friend WithEvents Feu_Rouge_Voie_B_2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Label_Temps As System.Windows.Forms.Label
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents Temps_Feu_Rouge As System.Windows.Forms.Label
    Friend WithEvents Temps_Feu_Vert As System.Windows.Forms.Label
    Friend WithEvents Temps_Feu_Orange As System.Windows.Forms.Label
    Friend WithEvents LineShape8 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents LineShape7 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents LineShape6 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents LineShape5 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents LineShape4 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents LineShape3 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents LineShape2 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents LineShape1 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents Feu_Rouge_Voie_A_1 As System.Windows.Forms.PictureBox
    Friend WithEvents Feu_Vert_Voie_A_1 As System.Windows.Forms.PictureBox
    Friend WithEvents Feu_Orange_Voie_A_1 As System.Windows.Forms.PictureBox
    Friend WithEvents Feu_Orange_Voie_B_1 As System.Windows.Forms.PictureBox
    Friend WithEvents Feu_Vert_Voie_B_1 As System.Windows.Forms.PictureBox
    Friend WithEvents Feu_Orange_Voie_A_2 As System.Windows.Forms.PictureBox
    Friend WithEvents Feu_Vert_Voie_A_2 As System.Windows.Forms.PictureBox
    Friend WithEvents Feu_Vert_Voie_B_2 As System.Windows.Forms.PictureBox
    Friend WithEvents Feu_Orange_Voie_B_2 As System.Windows.Forms.PictureBox
    Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape4 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape3 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape2 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_Feu_Vert_B_1_1 As System.Windows.Forms.PictureBox
    Friend WithEvents Pieton_Feu_Rouge_B_1_1 As System.Windows.Forms.PictureBox
    Friend WithEvents Pieton_Feu_Rouge_B_1_2 As System.Windows.Forms.PictureBox
    Friend WithEvents Pieton_Feu_Vert_B_1_2 As System.Windows.Forms.PictureBox
    Friend WithEvents Pieton_Feu_Vert_B_2_2 As System.Windows.Forms.PictureBox
    Friend WithEvents Pieton_Feu_Rouge_B_2_2 As System.Windows.Forms.PictureBox
    Friend WithEvents Pieton_Feu_Vert_B_2_1 As System.Windows.Forms.PictureBox
    Friend WithEvents Pieton_Feu_Rouge_B_2_1 As System.Windows.Forms.PictureBox
    Friend WithEvents Pieton_Feu_Rouge_A_2_2 As System.Windows.Forms.PictureBox
    Friend WithEvents Pieton_Feu_Vert_A_2_2 As System.Windows.Forms.PictureBox
    Friend WithEvents Pieton_Feu_Vert_A_2_1 As System.Windows.Forms.PictureBox
    Friend WithEvents Pieton_Feu_Rouge_A_2_1 As System.Windows.Forms.PictureBox
    Friend WithEvents Pieton_Feu_Rouge_A_1_2 As System.Windows.Forms.PictureBox
    Friend WithEvents Pieton_Feu_Vert_A_1_2 As System.Windows.Forms.PictureBox
    Friend WithEvents Pieton_Feu_Rouge_A_1_1 As System.Windows.Forms.PictureBox
    Friend WithEvents Pieton_Feu_Vert_A_1_1 As System.Windows.Forms.PictureBox
    Friend WithEvents Voiture_D_1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_H_1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_B_1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_G_1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Nombre_Voiture_B As System.Windows.Forms.ComboBox
    Friend WithEvents Nombre_Voiture_G As System.Windows.Forms.ComboBox
    Friend WithEvents Nombre_Voiture_D As System.Windows.Forms.ComboBox
    Friend WithEvents Nombre_Voiture_H As System.Windows.Forms.ComboBox
    Friend WithEvents Voiture_H_6 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_H_7 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_B_8 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_B_7 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_B_6 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_B_5 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_B_4 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_B_3 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_H_8 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_B_2 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_H_5 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_H_4 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_H_3 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_H_2 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_D_9 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_D_11 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_D_10 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_D_8 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_D_7 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_D_6 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_G_6 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_D_5 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_G_9 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_G_10 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_G_11 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_G_8 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_D_4 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_D_3 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_D_2 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_G_7 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_G_5 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_G_4 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_G_3 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Voiture_G_2 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape11 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape12 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape10 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape9 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape8 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape7 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape6 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape5 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_G_D_2 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_G_D_3 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_G_D_4 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_G_D_5 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_G_D_6 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_G_D_7 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_G_D_8 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_G_G_8 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_G_G_7 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_G_G_6 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_G_G_5 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_G_G_4 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_G_G_3 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_G_G_2 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_B_B_1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_G_D_1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_B_H_10 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_G_G_9 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_B_1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_G_G_1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_H_10 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_G_D_9 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_D_G_1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_B_10 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_D_D_9 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_H_1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_B_B_10 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_B_H_1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_D_D_1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_D_G_9 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Nombre_Pietons_GG As System.Windows.Forms.ComboBox
    Friend WithEvents Nombre_Pietons_HB As System.Windows.Forms.ComboBox
    Friend WithEvents Nombre_Pietons_BB As System.Windows.Forms.ComboBox
    Friend WithEvents Nombre_Pietons_BH As System.Windows.Forms.ComboBox
    Friend WithEvents Pieton_B_B_9 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_B_H_2 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_B_H_3 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_B_B_8 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_B_B_7 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_B_H_4 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_B_H_5 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_B_B_6 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_B_B_5 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_B_H_6 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_B_H_7 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_B_B_4 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_B_B_3 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_B_H_8 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_B_H_9 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_B_B_2 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_H_9 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_B_2 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_H_8 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_B_3 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_H_7 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_B_4 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_H_6 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_B_5 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_H_5 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_B_6 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_H_4 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_B_7 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_H_3 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_B_8 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_H_2 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_H_B_9 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_D_D_2 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_D_G_8 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_D_G_7 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_D_D_3 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_D_D_4 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_D_G_6 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_D_G_5 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_D_D_5 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_D_D_6 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_D_G_4 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_D_G_3 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_D_D_7 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_D_D_8 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Pieton_D_G_2 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Nombre_Pietons_HH As System.Windows.Forms.ComboBox
    Friend WithEvents Nombre_Pietons_DG As System.Windows.Forms.ComboBox
    Friend WithEvents Nombre_Pietons_DD As System.Windows.Forms.ComboBox
    Friend WithEvents Nombre_Pietons_GD As System.Windows.Forms.ComboBox

End Class
