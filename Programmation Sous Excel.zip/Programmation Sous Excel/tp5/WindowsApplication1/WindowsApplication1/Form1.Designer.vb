﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label_Choix = New System.Windows.Forms.Label()
        Me.Choix = New System.Windows.Forms.ComboBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Retour = New System.Windows.Forms.Button()
        Me.Label_Filtre1 = New System.Windows.Forms.Label()
        Me.Filtre1 = New System.Windows.Forms.TextBox()
        Me.Continuer = New System.Windows.Forms.Button()
        Me.Trouver = New System.Windows.Forms.Button()
        Me.Label_Filtre2 = New System.Windows.Forms.Label()
        Me.Filtre2 = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label_Choix
        '
        Me.Label_Choix.AutoSize = True
        Me.Label_Choix.Location = New System.Drawing.Point(211, 35)
        Me.Label_Choix.Name = "Label_Choix"
        Me.Label_Choix.Size = New System.Drawing.Size(119, 13)
        Me.Label_Choix.TabIndex = 0
        Me.Label_Choix.Text = "Que voulez vous faire ?"
        '
        'Choix
        '
        Me.Choix.FormattingEnabled = True
        Me.Choix.Items.AddRange(New Object() {"Noms Etudiants dans une ville donnée", "Données des Etudiants avec le même nom donnée", "Moyenne d'un Etudiant", "Supprimer Etudiants qui ont un prénom qui commencent par une lettre donnée", "Fussionner les éléments"})
        Me.Choix.Location = New System.Drawing.Point(83, 70)
        Me.Choix.Name = "Choix"
        Me.Choix.Size = New System.Drawing.Size(352, 21)
        Me.Choix.TabIndex = 1
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(83, 250)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(352, 95)
        Me.ListBox1.TabIndex = 2
        Me.ListBox1.Visible = False
        '
        'Retour
        '
        Me.Retour.Location = New System.Drawing.Point(231, 400)
        Me.Retour.Name = "Retour"
        Me.Retour.Size = New System.Drawing.Size(75, 23)
        Me.Retour.TabIndex = 3
        Me.Retour.Text = "Retour"
        Me.Retour.UseVisualStyleBackColor = True
        '
        'Label_Filtre1
        '
        Me.Label_Filtre1.AutoSize = True
        Me.Label_Filtre1.Location = New System.Drawing.Point(258, 112)
        Me.Label_Filtre1.Name = "Label_Filtre1"
        Me.Label_Filtre1.Size = New System.Drawing.Size(26, 13)
        Me.Label_Filtre1.TabIndex = 4
        Me.Label_Filtre1.Text = "Ville"
        Me.Label_Filtre1.Visible = False
        '
        'Filtre1
        '
        Me.Filtre1.Location = New System.Drawing.Point(210, 139)
        Me.Filtre1.Name = "Filtre1"
        Me.Filtre1.Size = New System.Drawing.Size(120, 20)
        Me.Filtre1.TabIndex = 5
        Me.Filtre1.Visible = False
        '
        'Continuer
        '
        Me.Continuer.Location = New System.Drawing.Point(231, 371)
        Me.Continuer.Name = "Continuer"
        Me.Continuer.Size = New System.Drawing.Size(75, 23)
        Me.Continuer.TabIndex = 6
        Me.Continuer.Text = "Continuer"
        Me.Continuer.UseVisualStyleBackColor = True
        '
        'Trouver
        '
        Me.Trouver.Location = New System.Drawing.Point(231, 371)
        Me.Trouver.Name = "Trouver"
        Me.Trouver.Size = New System.Drawing.Size(75, 23)
        Me.Trouver.TabIndex = 7
        Me.Trouver.Text = "Trouver"
        Me.Trouver.UseVisualStyleBackColor = True
        Me.Trouver.Visible = False
        '
        'Label_Filtre2
        '
        Me.Label_Filtre2.AutoSize = True
        Me.Label_Filtre2.Location = New System.Drawing.Point(241, 180)
        Me.Label_Filtre2.Name = "Label_Filtre2"
        Me.Label_Filtre2.Size = New System.Drawing.Size(43, 13)
        Me.Label_Filtre2.TabIndex = 8
        Me.Label_Filtre2.Text = "Prenom"
        Me.Label_Filtre2.Visible = False
        '
        'Filtre2
        '
        Me.Filtre2.Location = New System.Drawing.Point(210, 205)
        Me.Filtre2.Name = "Filtre2"
        Me.Filtre2.Size = New System.Drawing.Size(120, 20)
        Me.Filtre2.TabIndex = 9
        Me.Filtre2.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(583, 435)
        Me.Controls.Add(Me.Filtre2)
        Me.Controls.Add(Me.Label_Filtre2)
        Me.Controls.Add(Me.Trouver)
        Me.Controls.Add(Me.Continuer)
        Me.Controls.Add(Me.Filtre1)
        Me.Controls.Add(Me.Label_Filtre1)
        Me.Controls.Add(Me.Retour)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Choix)
        Me.Controls.Add(Me.Label_Choix)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label_Choix As System.Windows.Forms.Label
    Friend WithEvents Choix As System.Windows.Forms.ComboBox
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents Retour As System.Windows.Forms.Button
    Friend WithEvents Label_Filtre1 As System.Windows.Forms.Label
    Friend WithEvents Filtre1 As System.Windows.Forms.TextBox
    Friend WithEvents Continuer As System.Windows.Forms.Button
    Friend WithEvents Trouver As System.Windows.Forms.Button
    Friend WithEvents Label_Filtre2 As System.Windows.Forms.Label
    Friend WithEvents Filtre2 As System.Windows.Forms.TextBox

End Class
