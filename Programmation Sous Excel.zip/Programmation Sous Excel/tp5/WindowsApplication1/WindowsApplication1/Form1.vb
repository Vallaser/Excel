﻿Imports System.IO
Public Class Form1

    Dim EtatCivil As String = "D:\EtatCivil.txt"
    Dim Note As String = "D:\Note.txt"
    Dim Adresse As String = "D:\Adresse.txt"
    Dim Ensemble As String = "D:\Ensemble.txt"


    Private Sub Continuer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Continuer.Click
        If (Choix.Text = "Noms Etudiants dans une ville donnée") Then
            Label_Choix.Visible = False
            Choix.Visible = False
            Continuer.Visible = False

            Label_Filtre1.Visible = True
            Filtre1.Visible = True
            Trouver.Visible = True

            Label_Filtre1.Text = "Ville"
        ElseIf (Choix.Text = "Données des Etudiants avec le même nom donnée") Then
            Label_Choix.Visible = False
            Choix.Visible = False
            Continuer.Visible = False

            Label_Filtre1.Visible = True
            Filtre1.Visible = True
            Trouver.Visible = True

            Label_Filtre1.Text = "Nom"
        ElseIf (Choix.Text = "Moyenne d'un Etudiant") Then
            Label_Choix.Visible = False
            Choix.Visible = False
            Continuer.Visible = False

            Label_Filtre1.Visible = True
            Label_Filtre2.Visible = True
            Filtre1.Visible = True
            Filtre2.Visible = True
            Trouver.Visible = True

            Label_Filtre1.Text = "Nom"
            Label_Filtre2.Text = "Prenom"
        ElseIf (Choix.Text = "Supprimer Etudiants qui ont un prénom qui commencent par une lettre donnée") Then
            Label_Choix.Visible = False
            Choix.Visible = False
            Continuer.Visible = False

            Label_Filtre1.Visible = True
            Filtre1.Visible = True
            Trouver.Visible = True

            Label_Filtre1.Text = "Lettre"

        ElseIf (Choix.Text = "Fussionner les éléments") Then
            Dim path As String = Ensemble
            Dim fs As FileStream = File.Create(path)
            fs.Close()
            Dim monStreamReader = New StreamReader(EtatCivil)
            Dim ligne As String
            Dim trouver As Boolean = False
            Dim texte(1000) As String
            Dim nums(1000) As String
            Dim i As Integer = 0

            Do
                ligne = monStreamReader.ReadLine

                If (ligne Is Nothing) Then

                Else

                    Dim words As String() = ligne.ToString.Split(New Char() {" "c})

                    texte(i) = words(0) + " " + words(1)

                    nums(i) = words(0)
                    i = i + 1

                End If
            Loop Until ligne Is Nothing
            monStreamReader.Close()


            monStreamReader = New StreamReader(Adresse)
            Dim k As Integer = 0
            Do
                ligne = monStreamReader.ReadLine

                If (ligne Is Nothing) Then

                Else

                    Dim words As String() = ligne.ToString.Split(New Char() {" "c})

                    For Each num In nums
                        If (num = words(0)) Then
                            texte(k) = texte(k) + " " + words(2)
                        End If
                        k = k + 1
                    Next
                End If
            Loop Until ligne Is Nothing
            monStreamReader.Close()

            monStreamReader = New StreamReader(Note)
            k = 0
            Do
                ligne = monStreamReader.ReadLine

                If (ligne Is Nothing) Then

                Else

                    Dim words As String() = ligne.ToString.Split(New Char() {" "c})

                    For Each num In nums
                        If (num = words(0)) Then
                            texte(k) = texte(k) + " " + words(1)
                        End If
                        k = k + 1
                    Next
                End If
            Loop Until ligne Is Nothing
            monStreamReader.Close()

            For j As Integer = 0 To i - 1
                Dim file As System.IO.StreamWriter
                file = My.Computer.FileSystem.OpenTextFileWriter(Ensemble, True)
                file.WriteLine(texte(j))
                MsgBox("Fusion réussi !")
                file.Close()
            Next


        Else
                MsgBox("Le choix n'est pas correct !")
        End If


    End Sub

    Private Sub Retour_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Retour.Click

        ListBox1.Items.Clear()

        Trouver.Visible = False
        Label_Filtre1.Visible = False
        Label_Filtre2.Visible = False
        Filtre1.Visible = False
        Filtre2.Visible = False
        ListBox1.Visible = False

        Label_Choix.Visible = True
        Choix.Visible = True
        Continuer.Visible = True
    End Sub

    Private Sub Trouver_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Trouver.Click
        If (Choix.Text = "Noms Etudiants dans une ville donnée") Then
            Dim monStreamReader = New StreamReader(Adresse)
            Dim ligne As String
            Dim trouver As Boolean = False
            Dim nums(1000) As String
            Dim i As Integer = 0
            Do
                ligne = monStreamReader.ReadLine

                'MonTest = ligne Like "*" & "" & TextBox1.Text & "" & "*"

                If (ligne Is Nothing) Then

                Else

                    Dim words As String() = ligne.ToString.Split(New Char() {" "c})

                    If (words(2) = Filtre1.Text) Then

                        trouver = True

                        nums(i) = words(0)
                        i = i + 1

                        Label_Filtre1.Visible = False
                        Filtre1.Visible = False
                        ListBox1.Visible = True

                    End If
                End If
            Loop Until ligne Is Nothing
            monStreamReader.Close()

            If (trouver = False) Then
                MsgBox("Aucune personne trouvée")

            Else
                monStreamReader = New StreamReader(EtatCivil)
                Do
                    ligne = monStreamReader.ReadLine

                    If (ligne Is Nothing) Then

                    Else

                        Dim words As String() = ligne.ToString.Split(New Char() {" "c})

                        For Each num In nums
                            If (words(0) = num) Then
                                ListBox1.Items.Add(words(1))
                            End If
                        Next
                    End If
                Loop Until ligne Is Nothing
                monStreamReader.Close()
            End If



        ElseIf (Choix.Text = "Données des Etudiants avec le même nom donnée") Then
            Dim monStreamReader = New StreamReader(EtatCivil)
            Dim ligne As String
            Dim trouver As Boolean = False
            Dim nums(1000) As String
            Dim i As Integer = 0
            Do
                ligne = monStreamReader.ReadLine

                'MonTest = ligne Like "*" & "" & TextBox1.Text & "" & "*"

                If (ligne Is Nothing) Then

                Else

                    Dim words As String() = ligne.ToString.Split(New Char() {" "c})

                    If (words(1) = Filtre1.Text) Then

                        trouver = True

                        nums(i) = words(0)
                        ListBox1.Items.Add(words(0) + " " + words(1) + " " + words(2))
                        i = i + 1

                        Label_Filtre1.Visible = False
                        Filtre1.Visible = False
                        ListBox1.Visible = True

                    End If
                End If
            Loop Until ligne Is Nothing
            monStreamReader.Close()

            If (trouver = False) Then
                MsgBox("Aucune personne trouvée")

            Else
                monStreamReader = New StreamReader(Adresse)
                Do
                    ligne = monStreamReader.ReadLine

                    If (ligne Is Nothing) Then

                    Else

                        Dim words As String() = ligne.ToString.Split(New Char() {" "c})

                        Dim j As Integer = 0

                        For Each num In nums
                            If (words(0) = num) Then
                                ListBox1.Items(j) = ListBox1.Items(j) + " " + words(2)
                            End If
                            j = j + 1
                        Next
                    End If
                Loop Until ligne Is Nothing
                monStreamReader.Close()

            End If


        ElseIf (Choix.Text = "Moyenne d'un Etudiant") Then
            Dim monStreamReader = New StreamReader(EtatCivil)
            Dim ligne As String
            Dim trouver As Boolean = False
            Dim nums(1000) As String
            Dim i As Integer = 0
            Do
                ligne = monStreamReader.ReadLine

                'MonTest = ligne Like "*" & "" & TextBox1.Text & "" & "*"

                If (ligne Is Nothing) Then

                Else

                    Dim words As String() = ligne.ToString.Split(New Char() {" "c})

                    If (words(1) = Filtre1.Text And words(2) = Filtre2.Text) Then

                        trouver = True

                        nums(i) = words(0)
                        i = i + 1

                        Label_Filtre1.Visible = False
                        Label_Filtre2.Visible = False
                        Filtre1.Visible = False
                        Filtre2.Visible = False
                        ListBox1.Visible = True

                    End If
                End If
            Loop Until ligne Is Nothing
            monStreamReader.Close()
            If (trouver = False) Then
                MsgBox("Aucune personne trouvée")

            Else
                monStreamReader = New StreamReader(Note)
                Do
                    ligne = monStreamReader.ReadLine

                    If (ligne Is Nothing) Then

                    Else

                        Dim words As String() = ligne.ToString.Split(New Char() {" "c})

                        For Each num In nums
                            If (words(0) = num) Then
                                Dim Tp As Integer = Val(words(1))
                                Dim Ds As Integer = Val(words(2))
                                Dim moyenne As Integer = (Tp * 1 + Ds * 2) / 3
                                ListBox1.Items.Add(moyenne)
                            End If
                        Next
                    End If
                Loop Until ligne Is Nothing
                monStreamReader.Close()

            End If
        ElseIf (Choix.Text = "Supprimer Etudiants qui ont un prénom qui commencent par une lettre donnée") Then
            Dim monStreamReader = New StreamReader(EtatCivil)
            Dim ligne As String
            Dim trouver As Boolean = False
            Dim nums(1000) As String
            Dim i As Integer = 0
            Do
                ligne = monStreamReader.ReadLine

                'MonTest = ligne Like "*" & "" & TextBox1.Text & "" & "*"

                If (ligne Is Nothing) Then

                Else

                    Dim words As String() = ligne.ToString.Split(New Char() {" "c})

                    Dim lettre1 As Char
                    Dim lettre2 As Char

                    lettre1 = Mid(words(2), 1, 1)
                    lettre2 = Mid(Filtre1.Text, 1, 1)

                    If (lettre1 = lettre2) Then

                        MsgBox(words(2))

                        trouver = True

                        nums(i) = words(0)
                        i = i + 1

                    End If

                End If
            Loop Until ligne Is Nothing
            monStreamReader.Close()

            If (trouver = False) Then
                MsgBox("Aucune personne trouvée")
            Else

                For j As Integer = 0 To i - 1
                    MsgBox(nums(j))
                    System.IO.File.WriteAllLines(EtatCivil, System.IO.File.ReadAllLines(EtatCivil).Where(New Func(Of String, Boolean)(Function(s As String) (Not s.Contains(nums(j))))))
                    System.IO.File.WriteAllLines(Note, System.IO.File.ReadAllLines(Note).Where(New Func(Of String, Boolean)(Function(s As String) (Not s.Contains(nums(j))))))
                    System.IO.File.WriteAllLines(Adresse, System.IO.File.ReadAllLines(Adresse).Where(New Func(Of String, Boolean)(Function(s As String) (Not s.Contains(nums(j))))))

                    MsgBox("Suppression réussi !")
                Next
            End If

        ElseIf (Choix.Text = "Fussionner les éléments") Then

        End If

    End Sub

    Private Sub Label_Choix_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label_Choix.Click

    End Sub
End Class
