﻿Public Class Form1
    ' Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
    '   Me.Text = "salut"
    '    Button1.Text = "tuto"
    ' End Sub

    'Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
    '    Button2.Visible = False
    '   TextBox1.Text = "123"
    ' End Sub

    '  Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    '  End Sub

    'Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
    '   If TextBox1.Text = "123" Then
    '      MsgBox("Salut !")
    ' End If
    ' End Sub

    'Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    'End Sub
















End Class
