﻿Imports System.IO

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        lectureFichier("D:\Etatcivil.txt")
    End Sub



    Sub lectureFichier(ByVal fichier As String)
        Dim texte As String = ""
        Try
            Dim monStreamReader As New StreamReader(fichier)
            Dim ligne As String
            Do
                ligne = monStreamReader.ReadLine
                texte = texte + ligne + Chr(10)
            Loop Until ligne Is Nothing
            monStreamReader.Close()
        Catch ex As Exception
            MsgBox("Une erreur est survenue au cours de l'accès en lecture du fichier de configuration du logiciel." & vbCrLf & vbCrLf & "Veuillez vérifier l'emplacement : " &
                   fichier, MsgBoxStyle.Critical, "Erreur lors e l'ouverture du fichier conf...")
        End Try
        RichTextBox1.Text = texte
    End Sub
    
End Class
